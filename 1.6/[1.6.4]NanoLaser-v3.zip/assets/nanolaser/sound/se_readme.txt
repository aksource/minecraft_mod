cursor(cursor1.wav)
sniper(se03.wav)
normal(se04.wav)
http://www.tam-music.com/se/se-menu.html