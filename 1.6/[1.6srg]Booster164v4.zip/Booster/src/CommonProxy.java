package Booster;

import net.minecraft.world.World;

public class CommonProxy
{
	public CommonProxy(){}
	public void registerClientInformation(){}
	public World getClientWorld()
	{
		return null;
	}
}