package ee_aa;

import java.util.ArrayList;

import net.minecraft.src.Block;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.TileEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_EEAA;
import net.minecraft.src.forge.ITextureProvider;

public class BlockAEGU extends Block implements ITextureProvider
{
	private byte blockCount;
	private byte advCount;
	private byte ultimateCount;
	public BlockAEGU(int par1) {
		super(par1, Material.rock);
		this.setLightValue(1.0f);
		setStepSound(soundGlassFootstep);
		setHardness(0.3F);
	}
	@Override
	public String getTextureFile() {
		return mod_EEAA.Terrain;
	}
	public int getBlockTextureFromSideAndMetadata(int par1, int par2)
	{
		boolean odd = par2 % 2 ==1;
		if(odd)
			return par2 / 2 + 2;
		else
			return par2 / 2 + 2 + 16;
	}
	public void onBlockAdded(World world, int x, int y, int z)
	{
		boolean odd = world.getBlockMetadata(x, y, z)  % 2 == 1;
		if(odd)
			world.setBlockMetadata(x, y, z, world.getBlockMetadata(x, y, z) - 1);
		TileCondenserMK2 tile = this.searchCondenserMk2(world, x, y, z);
		if(tile == null)
			return;
		if(this.countAEGUBlock(world, tile.xCoord, tile.yCoord, tile.zCoord))
		{
			tile.setActivateState(true);
			tile.setBlockAEGUCount(blockCount);
			tile.setAdvAEGUcount(advCount);
			tile.setUltimateAEGUCount(ultimateCount);
		}
		if(tile.isActivated())
		{
			this.changeBlockActive(world, tile.xCoord, tile.yCoord, tile.zCoord);
		}
	}
	public void onBlockRemoval(World world, int x, int y, int z)
	{
		TileCondenserMK2 tile = this.searchCondenserMk2(world, x, y, z);
		if(tile != null && tile.isActivated() && !this.countAEGUBlock(world, tile.xCoord, tile.yCoord, tile.zCoord))
		{
			tile.setActivateState(false);
			this.changeBlockDeActive(world, tile.xCoord, tile.yCoord, tile.zCoord);
		}
	}
	protected int damageDropped(int par1)
	{
		boolean odd = par1 % 2 == 1;
		if(odd)
			return par1 - 1;
		else
			return par1;
	}
	public boolean canSilkHarvest(World world, EntityPlayer player, int x, int y, int z, int metadata)
	{
		return false;
	}
//	public boolean canPlaceBlockAt(World par1World, int par2, int par3, int par4)
//	{
//		if(super.canPlaceBlockAt(par1World, par2, par3, par4))
//		{
//			if(this.blockID == par1World.getBlockId(par2 - 3, par3, par4)
//					&& this.blockID == par1World.getBlockId(par2 - 2, par3, par4)
//					&& this.blockID == par1World.getBlockId(par2 - 1, par3, par4)
//					|| this.blockID == par1World.getBlockId(par2 + 1, par3, par4)
//					&& this.blockID == par1World.getBlockId(par2 + 2, par3, par4)
//					&& this.blockID == par1World.getBlockId(par2 + 3, par3, par4)
//					|| this.blockID == par1World.getBlockId(par2, par3 - 3, par4)
//					&& this.blockID == par1World.getBlockId(par2, par3 - 2, par4)
//					&& this.blockID == par1World.getBlockId(par2, par3 - 1, par4)
//					|| this.blockID == par1World.getBlockId(par2, par3 + 1, par4)
//					&& this.blockID == par1World.getBlockId(par2, par3 + 2, par4)
//					&& this.blockID == par1World.getBlockId(par2, par3 + 3, par4)
//					|| this.blockID == par1World.getBlockId(par2, par3, par4 - 3)
//					&& this.blockID == par1World.getBlockId(par2, par3, par4 - 2)
//					&& this.blockID == par1World.getBlockId(par2, par3, par4 - 1)
//					|| this.blockID == par1World.getBlockId(par2, par3, par4 + 1)
//					&& this.blockID == par1World.getBlockId(par2, par3, par4 + 2)
//					&& this.blockID == par1World.getBlockId(par2, par3, par4 + 3))
//			{
//				return false;
//			}
//			else return true;
//		}
//		else return false;
//	}
	public boolean blockActivated(World world, int x, int y, int z, EntityPlayer player)
	{
		if (player.isSneaking())
		{
			return false;
		}
		else
		{
			TileCondenserMK2 tile = this.searchCondenserMk2(world, x, y, z);
			if(tile != null && tile.isActivated())
			{
				player.openGui(mod_EEAA.getInstance(), mod_EEAA.CondenserMK2Gui, world, tile.xCoord, tile.yCoord, tile.zCoord);
				return true;
			}
			else return false;
		}
	}
	private TileCondenserMK2 searchCondenserMk2(World world, int x,int y, int z)
	{
		for(int i = -1;i<2;i++)
			for(int j = -1;j<2;j++)
				for(int k = -1;k<2;k++)
				{
					TileEntity tile = world.getBlockTileEntity(x + i, y + j, z + k);
					if(tile != null && tile instanceof TileCondenserMK2)
					{
						return (TileCondenserMK2) tile;
					}
				}
		return null;
	}
	private void changeBlockActive(World world, int tileX, int tileY, int TileZ)
	{
		boolean even;
		for(int i = -1;i<2;i++)
			for(int j = -1;j<2;j++)
				for(int k = -1;k<2;k++)
				{
					if(this.blockID == world.getBlockId(tileX + i, tileY + j, TileZ + k))
					{
						even = world.getBlockMetadata(tileX + i, tileY + j, TileZ + k) % 2 == 0;
						if(even)
							world.setBlockMetadata(tileX + i, tileY + j, TileZ + k, world.getBlockMetadata(tileX + i, tileY + j, TileZ + k) + 1);
					}
				}
	}
	private void changeBlockDeActive(World world, int tileX, int tileY, int TileZ)
	{
		boolean odd;
		for(int i = -1;i<2;i++)
			for(int j = -1;j<2;j++)
				for(int k = -1;k<2;k++)
				{
					if(this.blockID == world.getBlockId(tileX + i, tileY + j, TileZ + k))
					{
						odd = world.getBlockMetadata(tileX + i, tileY + j, TileZ + k) % 2 == 1;
						if(odd)
							world.setBlockMetadata(tileX + i, tileY + j, TileZ + k, world.getBlockMetadata(tileX + i, tileY + j, TileZ + k) - 1);
					}
				}
	}
	private boolean countAEGUBlock(World world, int x,int y, int z)
	{
		this.blockCount = 0;
		this.advCount = 0;
		this.ultimateCount = 0;
		for(int i = -1;i<2;i++)
			for(int j = -1;j<2;j++)
				for(int k = -1;k<2;k++)
				{
					if(this.blockID == world.getBlockId(x + i, y + j, z + k) && world.getBlockMetadata(x + i, y + j, z + k) % 2 == 0)
					{
						this.blockCount++;
						if(world.getBlockMetadata(x + i, y + j, z + k) == 2/* || world.getBlockMetadata(x + i, y + j, z + k) == 3*/)
							this.advCount++;
						else if(world.getBlockMetadata(x + i, y + j, z + k) == 4/* || world.getBlockMetadata(x + i, y + j, z + k) == 5*/)
							this.ultimateCount++;
					}
				}
		if(this.blockCount > 24)
			return true;
		else return false;
	}
	public void addCreativeItems(ArrayList var1)
	{
		for(int i = 0; i<3;i++)
		{
			var1.add(new ItemStack(this, 1, i * 2));
		}
	}
}