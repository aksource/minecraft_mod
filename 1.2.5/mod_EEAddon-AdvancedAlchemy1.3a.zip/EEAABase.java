package net.minecraft.src.ee_aa;

import net.minecraft.src.EEProxy;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.InventoryPlayer;
import net.minecraft.src.ItemStack;
import net.minecraft.src.ModLoader;
import net.minecraft.src.ee.EEBase;
import net.minecraft.src.ee.ItemKleinStar;

public class EEAABase {
	
	//ItemStackがクラインの星かどうか判定。
	public static boolean isKleinStar(ItemStack itemStack) {
		return itemStack != null && itemStack.getItem() instanceof ItemKleinStar;
	}
	//ItemStackがクラインの星だった時のクラインの星のランク
	public static int getKleinLevel(ItemStack itemStack) {
		return EEBase.getKleinLevel(itemStack.itemID);
	}
	
	//クラインの星にEMCの値を加える。
    public static boolean addKleinStarPoints(ItemStack kleinStar, int points) {
        if (!isKleinStar(kleinStar))
        {
            return false;
        }
        else
        {
            ItemKleinStar var2 = (ItemKleinStar)kleinStar.getItem();

            if (var2.getKleinPoints(kleinStar) <= var2.getMaxPoints(kleinStar) - points)
            {
                var2.setKleinPoints(kleinStar, var2.getKleinPoints(kleinStar) + points);
                var2.onUpdate(kleinStar);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    
	//クラインの星からEMCの値を引く。
    public static boolean takeKleinStarPoints(ItemStack kleinStar, int points) {
        if (ModLoader.getMinecraftInstance().theWorld.isRemote || !isKleinStar(kleinStar))
        {
            return false;
        }
        else
        {
            ItemKleinStar var3 = (ItemKleinStar)kleinStar.getItem();

            if (var3.getKleinPoints(kleinStar) >= points)
            {
                var3.setKleinPoints(kleinStar, var3.getKleinPoints(kleinStar) - points);
                var3.onUpdate(kleinStar);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    
    //インベントリにあるクラインの星を走査してEMCの値を引く。
    public static boolean consumeKleinStarPoint(EntityPlayer entityPlayer, int points) {
        if (entityPlayer == null || EEProxy.isClient(entityPlayer.worldObj))
        {
            return false;
        }
        else
        {
            InventoryPlayer var2 = entityPlayer.inventory;

            for (int var3 = 0; var3 < var2.mainInventory.length; ++var3)
            {
                if (var2.getStackInSlot(var3) != null)
                {
                    ItemStack var4 = var2.getStackInSlot(var3);

                    if (isKleinStar(var4) && takeKleinStarPoints(var4, points))
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}
