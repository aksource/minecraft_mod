package ee_aa;

import net.minecraft.src.ItemStack;

public interface IKleinItem {
	
	public void setChargedPoints(ItemStack itemStack, int points);
	
	public int getChargedPoints(ItemStack itemStack);
	
	public int getMaxPoints(ItemStack itemStack);
	
	public int getKleinLevel(ItemStack itemStack);
}
