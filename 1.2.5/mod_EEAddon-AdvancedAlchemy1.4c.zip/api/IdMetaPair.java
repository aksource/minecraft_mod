package ee_aa;

public class IdMetaPair {
	private int id;
	private int meta;
	
	public IdMetaPair(int par1, int par2) {
		id = par1;
		meta = par2;
	}

	
	
	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public int getMeta() {
		return meta;
	}



	public void setMeta(int meta) {
		this.meta = meta;
	}



	@Override
	public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        result = prime * result + meta;
        return result;
	}

	@Override
	public String toString() {
		return String.format("IdMetaPair [ID:%d, META:%d]", this.id, this.meta);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		
		if (obj == null) {
			return false;
		}
		
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		
		IdMetaPair otherIdMetaPair = (IdMetaPair) obj;
		
		return this.id == otherIdMetaPair.id && this.meta == otherIdMetaPair.meta;
	}
	
	
}
