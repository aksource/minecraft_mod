package ee_aa;


import java.util.List;

import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.BlockContainer;
import net.minecraft.src.EEProxy;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityArrow;
import net.minecraft.src.EntityBlaze;
import net.minecraft.src.EntityCaveSpider;
import net.minecraft.src.EntityChicken;
import net.minecraft.src.EntityCow;
import net.minecraft.src.EntityCreeper;
import net.minecraft.src.EntityEnderman;
import net.minecraft.src.EntityFireball;
import net.minecraft.src.EntityGhast;
import net.minecraft.src.EntityIronGolem;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLightningBolt;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityMagmaCube;
import net.minecraft.src.EntityMob;
import net.minecraft.src.EntityMooshroom;
import net.minecraft.src.EntityOcelot;
import net.minecraft.src.EntityPig;
import net.minecraft.src.EntityPigZombie;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntitySheep;
import net.minecraft.src.EntitySilverfish;
import net.minecraft.src.EntitySkeleton;
import net.minecraft.src.EntitySlime;
import net.minecraft.src.EntitySnowman;
import net.minecraft.src.EntitySpider;
import net.minecraft.src.EntityVillager;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.EntityXPOrb;
import net.minecraft.src.EntityZombie;
import net.minecraft.src.EnumMovingObjectType;
import net.minecraft.src.IInventory;
import net.minecraft.src.InventoryPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.ModLoader;
import net.minecraft.src.MovingObjectPosition;
import net.minecraft.src.Vec3D;
import net.minecraft.src.World;
import net.minecraft.src.forge.ICraftingHandler;
import net.minecraft.src.forge.MinecraftForge;


public class EEAABase {

	// ItemStackがクラインの星かどうか判定。
	public static boolean isKleinStar(ItemStack itemStack) {
		return itemStack != null && itemStack.getItem() instanceof IKleinItem;
	}

	// ItemStackがクラインの星だった時のクラインの星のランク
	public static int getKleinLevel(ItemStack itemStack) {
		return itemStack != null && itemStack.getItem() instanceof IKleinItem ? ((IKleinItem) itemStack
				.getItem()).getKleinLevel(itemStack) : 0;
	}

	public static boolean canIncreaseKleinStarPoints(ItemStack var0, World var1) {
		if (var1.isRemote) {
			return false;
		} else {
			byte var2 = 1;
			return var0 == null ? false : (isKleinStar(var0) ? var0
					.getItemDamage() - var2 != 0 : false);
		}
	}

	// クラインの星にEMCの値を加える。
	public static boolean addKleinStarPoints(ItemStack kleinStar, int points) {
		if (!isKleinStar(kleinStar)) {
			return false;
		} else {
			IKleinItem var2 = (IKleinItem) kleinStar.getItem();
			int nowEMC = var2.getChargedPoints(kleinStar);
			if (nowEMC <= var2.getMaxPoints(kleinStar) - points) {
				var2.setChargedPoints(kleinStar, nowEMC + points);
				return true;
			} else {
				return false;
			}
		}
	}

	// クラインの星からEMCの値を引く。
	public static boolean takeKleinStarPoints(ItemStack kleinStar, int points) {
		if (ModLoader.getMinecraftInstance().theWorld.isRemote
				|| !isKleinStar(kleinStar)) {
			return false;
		} else {
			IKleinItem var3 = (IKleinItem) kleinStar.getItem();
			int nowEMC = var3.getChargedPoints(kleinStar);
			if (nowEMC >= points) {
				var3.setChargedPoints(kleinStar, nowEMC - points);
				return true;
			} else {
				return false;
			}
		}
	}

	// インベントリにあるクラインの星を走査してEMCの値を引く。
	public static boolean consumeKleinStarPoint(EntityPlayer entityPlayer,
			int points) {
		if (entityPlayer == null || entityPlayer.worldObj.isRemote) {
			return false;
		} else {
			InventoryPlayer var2 = entityPlayer.inventory;

			for (int var3 = 0; var3 < var2.mainInventory.length; ++var3) {
				if (var2.getStackInSlot(var3) != null) {
					ItemStack var4 = var2.getStackInSlot(var3);

					if (isKleinStar(var4) && takeKleinStarPoints(var4, points)) {
						return true;
					}
				}
			}

			return false;
		}
	}

	public static void ConsumeReagentForDuration(ItemStack var0,
			EntityPlayer var1, boolean var2) {

	}

	public static void ConsumeReagent(ItemStack var0, EntityPlayer var1,
			boolean var2) {
	
	}

	// 時流計があるかどうか。
	public static boolean hasWatchOfTime(ItemStack[] itemStacks) {

		return false;
	}

	// 補修の呪符があるかどうか。
	public static boolean hasRepairCharm(ItemStack[] itemStacks) {

		return false;
	}

	// 圧縮系アイテムがあるかどうか。
	public static int hasEternalDensity(ItemStack[] itemStacks) {

		return -1;
	}

	// 吸引の指輪があるかどうか。
	public static boolean hasAttractionRing(ItemStack[] itemStacks) {

		return false;
	}

	// 結界トーチがあるかどうか。
	public static boolean hasEETorch(ItemStack[] itemStacks) {
	
		return false;
	}

	// 補修の呪符のメソッド。
	public static void doRepair(ItemStack[] itemStacks) {

	}

	// 圧縮の宝珠のメソッド。
	public static void doCondense(ItemStack[] itemStacks, int eternalDensity, int startIndex) {
		if (eternalDensity != -1) {
			int var2 = 0;
			int var3;

			for (var3 = startIndex; var3 < itemStacks.length; ++var3) {
				if (itemStacks[var3] != null
						&& isValidMaterial(itemStacks[var3])
						&& EEMaps2.getEMCForMelting(itemStacks[var3]) > var2) {
					var2 = EEMaps2.getEMCForMelting(itemStacks[var3]);
				}
			}

			for (var3 = startIndex; var3 < itemStacks.length; ++var3) {
				if (itemStacks[var3] != null
						&& isValidMaterial(itemStacks[var3])
						&& EEMaps2.getEMCForMelting(itemStacks[var3]) < var2) {
					var2 = EEMaps2.getEMCForMelting(itemStacks[var3]);
				}
			}

			if (var2 < EEMaps2.getEMC(EEItem.redMatter.shiftedIndex)
					&& !doAnalyzingTier(itemStacks, itemStacks[eternalDensity],
							EEMaps2.getEMC(EEItem.redMatter.shiftedIndex), startIndex)
					&& var2 < EEMaps2.getEMC(EEItem.darkMatter.shiftedIndex)
					&& !doAnalyzingTier(itemStacks, itemStacks[eternalDensity],
							EEMaps2.getEMC(EEItem.darkMatter.shiftedIndex), startIndex)
					&& var2 < EEMaps2.getEMC(Item.diamond.shiftedIndex)
					&& !doAnalyzingTier(itemStacks, itemStacks[eternalDensity],
							EEMaps2.getEMC(Item.diamond.shiftedIndex), startIndex)
					&& var2 < EEMaps2.getEMC(Item.ingotGold.shiftedIndex)
					&& !doAnalyzingTier(itemStacks, itemStacks[eternalDensity],
							EEMaps2.getEMC(Item.ingotGold.shiftedIndex), startIndex)
					&& var2 < EEMaps2.getEMC(Item.ingotIron.shiftedIndex)
					&& doAnalyzingTier(itemStacks, itemStacks[eternalDensity],
							EEMaps2.getEMC(Item.ingotIron.shiftedIndex), startIndex)) {
				;
			}
		}
	}

	// 吸引の指輪のメソッド。Player引数
	public static void doAttractionOnPlayer(ItemStack[] itemStacks,
			World world, EntityPlayer var1) {
	
	}

	// 吸引の指輪のメソッド。ブロック用
	public static void doAttractionOnChest(ItemStack[] itemStacks, World world,
			int xCoord, int yCoord, int zCoord) {

	}

	private static void PullItems(Entity var1, int xCoord, int yCoord,
			int zCoord) {
	
	}

	private static void PullItems(Entity var1, EntityPlayer var2) {

	}

	private static void GrabItems(ItemStack[] itemStacks, Entity var1) {
	
	}

	private static void PushDenseStacks(ItemStack[] itemStacks,
			EntityLootBall var1) {
		for (int var2 = 0; var2 < var1.items.length; ++var2) {
			if (var1.items[var2] != null
					&& PushStack(itemStacks, var1.items[var2], 0)) {
				var1.items[var2] = null;
			}
		}
	}

	public static boolean PushStack(ItemStack[] itemStacks, ItemStack var1,
			EntityPlayer var2) {
		int var3;

		for (var3 = 0; var3 < itemStacks.length; ++var3) {
			if (var1 != null) {
				if (itemStacks[var3] == null) {
					itemStacks[var3] = var1.copy();
					var1 = null;
					return true;
				}

				if (itemStacks[var3].isItemEqual(var1)
						&& ItemStack.func_46154_a(itemStacks[var3], var1)) {
					while (itemStacks[var3].stackSize < itemStacks[var3]
							.getMaxStackSize() && var1 != null) {
						++itemStacks[var3].stackSize;
						--var1.stackSize;

						if (var1.stackSize == 0) {
							var1 = null;
							return true;
						}
					}
				} else if (var3 == 103) {
					EntityItem var4 = new EntityItem(
							ModLoader.getMinecraftInstance().theWorld,
							var2.posX, var2.posY, var2.posZ, var1);
					var4.delayBeforeCanPickup = 1;
					ModLoader.getMinecraftInstance().theWorld
							.spawnEntityInWorld(var4);
					return true;
				}
			}
		}

		if (var1 != null) {
			for (var3 = 0; var3 < itemStacks.length; ++var3) {
				if (itemStacks[var3] == null) {
					itemStacks[var3] = var1.copy();
					var1 = null;
					return true;
				}
			}
		}
		return false;
	}

	private static boolean doAnalyzingTier(ItemStack[] itemStacks,
			ItemStack var1, int var2, int startIndex) {
		if (var1 == null) {
			return false;
		} else {
			int var3 = 0;
			int var4;

			for (var4 = startIndex; var4 < itemStacks.length; ++var4) {
				if (itemStacks[var4] != null
						&& isValidMaterial(itemStacks[var4])
						&& EEMaps2.getEMC(itemStacks[var4]) < var2) {
					var3 += EEMaps2.getEMC(itemStacks[var4])
							* itemStacks[var4].stackSize;
				}
			}

			if (var3 + emc(var1) < var2) {
				return false;
			} else {
				var4 = 0;

				while (var3 + emc(var1) >= var2 && var4 < 10) {
					++var4;
					ConsumeMaterialBelowTier(itemStacks, var1, var2, startIndex);
				}

				if (emc(var1) >= var2
						&& roomFor(itemStacks, getProduct(var2), startIndex)) {
					PushStack(itemStacks, getProduct(var2), startIndex);
					takeEMC(var1, var2);
				}

				return true;
			}
		}
	}

	public static boolean roomFor(ItemStack[] itemStacks, ItemStack var1,
			int startIndex) {
		if (var1 == null) {
			return false;
		} else {
			for (int var2 = startIndex; var2 < itemStacks.length; ++var2) {
				if (itemStacks[var2] == null) {
					return true;
				}

				if (itemStacks[var2].isItemEqual(var1)
						&& itemStacks[var2].stackSize <= var1.getMaxStackSize()
								- var1.stackSize) {
					return true;
				}
			}

			return false;
		}
	}

	private static ItemStack getProduct(int var1) {
		return null;
	}

	public static boolean PushStack(ItemStack[] itemStacks, ItemStack var1,
			int startIndex) {
		if (var1 == null) {
			return false;
		} else {
			for (int var2 = startIndex; var2 < itemStacks.length; ++var2) {
				if (itemStacks[var2] == null) {
					itemStacks[var2] = var1.copy();
					var1 = null;
					return true;
				}

				if (itemStacks[var2].isItemEqual(var1)
						&& ItemStack.func_46154_a(itemStacks[var2], var1)
						&& itemStacks[var2].stackSize <= var1.getMaxStackSize()
								- var1.stackSize) {
					itemStacks[var2].stackSize += var1.stackSize;
					var1 = null;
					return true;
				}
			}

			return false;
		}
	}

	private static void ConsumeMaterialBelowTier(ItemStack[] itemStacks,
			ItemStack var1, int var2, int startIndex) {
		for (int var3 = startIndex; var3 < itemStacks.length; ++var3) {
			if (itemStacks[var3] != null && isValidMaterial(itemStacks[var3])
					&& EEMaps2.getEMC(itemStacks[var3]) < var2) {
				addEMC(var1, EEMaps2.getEMC(itemStacks[var3]));
				--itemStacks[var3].stackSize;

				if (itemStacks[var3].stackSize == 0) {
					itemStacks[var3] = null;
				}

				return;
			}
		}
	}

	private static boolean isValidMaterial(ItemStack var1) {
		return false;
	}

	private static int emc(ItemStack var1) {
		return 0;
	}

	private static void takeEMC(ItemStack var1, int var2) {

	}

	private static void addEMC(ItemStack var1, int var2) {

	}

	public static void doLeftClick(World var0, EntityPlayer var1) {

	}

	public static void doAlternate(World var0, EntityPlayer var1) {

	}

	private static void armorCheck(EntityPlayer var0) {

	}

	@SuppressWarnings("unchecked")
	public static void doInterdiction(ItemStack var1, World var2,
			EntityPlayer var3) {

	}

	private static void PushEntities(Entity var1, EntityPlayer var2) {
		if (!(var1 instanceof EntityPlayer)) {
			if (var2.worldObj.rand.nextInt(1200) == 0
					&& var2.worldObj.canBlockSeeTheSky((int) var1.posX,
							(int) var1.posY, (int) var1.posZ)) {
				var2.worldObj.addWeatherEffect(new EntityLightningBolt(
						var2.worldObj, var1.posX, var1.posY, var1.posZ));
			}

			double var4 = var2.posX + 0.5D - var1.posX;
			double var6 = var2.posY + 0.5D - var1.posY;
			double var8 = var2.posZ + 0.5D - var1.posZ;
			double var10 = var4 * var4 + var6 * var6 + var8 * var8;
			var10 *= var10;

			if (var10 <= Math.pow(6.0D, 4.0D)) {
				double var12 = -(var4 * 0.019999999552965164D / var10)
						* Math.pow(6.0D, 3.0D);
				double var14 = -(var6 * 0.019999999552965164D / var10)
						* Math.pow(6.0D, 3.0D);
				double var16 = -(var8 * 0.019999999552965164D / var10)
						* Math.pow(6.0D, 3.0D);

				if (var12 > 0.0D) {
					var12 = 0.12000000000000001D;
				} else if (var12 < 0.0D) {
					var12 = -0.12000000000000001D;
				}

				if (var14 > 0.2D) {
					var14 = 0.12000000000000001D;
				} else if (var14 < -0.1D) {
					var14 = 0.12000000000000001D;
				}

				if (var16 > 0.0D) {
					var16 = 0.12000000000000001D;
				} else if (var16 < 0.0D) {
					var16 = -0.12000000000000001D;
				}

				var1.motionX += var12;
				var1.motionY += var14;
				var1.motionZ += var16;
			}
		}
	}

	private static boolean hasRedArmor(EntityPlayer var0) {
		return false;
	}

	public static void doToggle(World var0, EntityPlayer var1) {

	}

	public static void doRelease(World var0, EntityPlayer var1) {

	}

	private static void helmetCheck(EntityPlayer var0) {
		if (hasRedHelmet(var0) && getPlayerArmorOffensive(var0)) {
			float var1 = 1.0F;
			float var2 = var0.prevRotationPitch
					+ (var0.rotationPitch - var0.prevRotationPitch) * var1;
			float var3 = var0.prevRotationYaw
					+ (var0.rotationYaw - var0.prevRotationYaw) * var1;
			double var4 = var0.prevPosX + (var0.posX - var0.prevPosX) * var1;
			double var6 = var0.prevPosY + (var0.posY - var0.prevPosY) * var1
					+ 1.62D - var0.yOffset;
			double var8 = var0.prevPosZ + (var0.posZ - var0.prevPosZ) * var1;
			Vec3D var10 = Vec3D.createVector(var4, var6, var8);
			float var11 = MathHelper.cos(-var3 * 0.01745329F - (float) Math.PI);
			float var12 = MathHelper.sin(-var3 * 0.01745329F - (float) Math.PI);
			float var13 = -MathHelper.cos(-var2 * 0.01745329F);
			float var14 = MathHelper.sin(-var2 * 0.01745329F);
			float var15 = var12 * var13;
			float var17 = var11 * var13;
			double var18 = 150.0D;
			Vec3D var20 = var10.addVector(var15 * var18, var14 * var18, var17
					* var18);
			MovingObjectPosition var21 = var0.worldObj.rayTraceBlocks_do(var10,
					var20, true);

			if (var21 == null) {
				return;
			}

			if (var21.typeOfHit == EnumMovingObjectType.TILE) {
				int var22 = var21.blockX;
				int var23 = var21.blockY;
				int var24 = var21.blockZ;
				var0.worldObj.addWeatherEffect(new EntityLightningBolt(
						var0.worldObj, var22, var23, var24));
			}
		}
	}

	private static boolean hasRedHelmet(EntityPlayer var0) {
		return false;
	}

	public static void doCharge(World var0, EntityPlayer var1) {

	}

	private static boolean hasOffensiveArmor(EntityPlayer var0) {
		return false;
	}

	private static boolean hasMovementArmor(EntityPlayer var0) {
		return false;
	}

	public static void doJumpTick(World var0, EntityPlayer var1) {
		bootsCheck(var1);
	}

	private static void bootsCheck(EntityPlayer var0) {
		if (hasRedBoots(var0) && getPlayerArmorMovement(var0)) {
			var0.motionY += 0.1D;
		}
	}

	private static boolean hasRedBoots(EntityPlayer var0) {
		return false;
	}

	public static void doSneakTick(World var0, EntityPlayer var1) {
		greavesCheck(var1);
	}

	private static void greavesCheck(EntityPlayer var0) {
	
	}

	private static void doShockwave(EntityPlayer var0) {
		List var1 = var0.worldObj.getEntitiesWithinAABB(EntityLiving.class,
				AxisAlignedBB.getBoundingBoxFromPool(var0.posX - 7.0D,
						var0.posY - 7.0D, var0.posZ - 7.0D, var0.posX + 7.0D,
						var0.posY + 7.0D, var0.posZ + 7.0D));

		for (int var2 = 0; var2 < var1.size(); ++var2) {
			Entity var3 = (Entity) var1.get(var2);

			if (!(var3 instanceof EntityPlayer)) {
				var3.motionX += 0.2D / (var3.posX - var0.posX);
				var3.motionY += 0.05999999865889549D;
				var3.motionZ += 0.2D / (var3.posZ - var0.posZ);
			}
		}

		List var6 = var0.worldObj.getEntitiesWithinAABB(EntityArrow.class,
				AxisAlignedBB.getBoundingBoxFromPool((float) var0.posX - 5.0F,
						var0.posY - 5.0D, (float) var0.posZ - 5.0F,
						(float) var0.posX + 5.0F, var0.posY + 5.0D,
						(float) var0.posZ + 5.0F));

		for (int var7 = 0; var7 < var6.size(); ++var7) {
			Entity var4 = (Entity) var6.get(var7);
			var4.motionX += 0.2D / (var4.posX - var0.posX);
			var4.motionY += 0.05999999865889549D;
			var4.motionZ += 0.2D / (var4.posZ - var0.posZ);
		}

		List var8 = var0.worldObj.getEntitiesWithinAABB(EntityFireball.class,
				AxisAlignedBB.getBoundingBoxFromPool((float) var0.posX - 5.0F,
						var0.posY - 5.0D, (float) var0.posZ - 5.0F,
						(float) var0.posX + 5.0F, var0.posY + 5.0D,
						(float) var0.posZ + 5.0F));

		for (int var9 = 0; var9 < var8.size(); ++var9) {
			Entity var5 = (Entity) var8.get(var9);
			var5.motionX += 0.2D / (var5.posX - var0.posX);
			var5.motionY += 0.05999999865889549D;
			var5.motionZ += 0.2D / (var5.posZ - var0.posZ);
		}
	}

	private static boolean hasRedGreaves(EntityPlayer var0) {
		return false;
	}

	public static boolean isNeutralEntity(Entity var0) {
		return var0 instanceof EntitySheep || var0 instanceof EntityCow
				|| var0 instanceof EntityPig || var0 instanceof EntityChicken
				|| var0 instanceof EntityMooshroom
				|| var0 instanceof EntityVillager
				|| var0 instanceof EntityOcelot || var0 instanceof EntityWolf
				|| var0 instanceof EntitySnowman
				|| var0 instanceof EntityIronGolem;
	}

	public static boolean isHostileEntity(Entity var0) {
		return var0 instanceof EntityCreeper || var0 instanceof EntityZombie
				|| var0 instanceof EntitySkeleton
				|| var0 instanceof EntitySpider
				|| var0 instanceof EntityCaveSpider
				|| var0 instanceof EntityEnderman
				|| var0 instanceof EntitySilverfish
				|| var0 instanceof EntitySlime || var0 instanceof EntityGhast
				|| var0 instanceof EntityMagmaCube
				|| var0 instanceof EntityPigZombie
				|| var0 instanceof EntityBlaze;
	}
}
