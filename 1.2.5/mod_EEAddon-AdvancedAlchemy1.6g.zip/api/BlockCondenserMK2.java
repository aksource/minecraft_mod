package ee_aa;

import java.util.ArrayList;
import java.util.Random;

import ee.TileEE;
import net.minecraft.src.BlockContainer;
import net.minecraft.src.EEProxy;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.TileEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_EE;
import net.minecraft.src.mod_EEAA;
import net.minecraft.src.forge.ITextureProvider;

public class BlockCondenserMK2 extends BlockContainer implements ITextureProvider
{
	private Random random = new Random();
	private byte blockCount;
	private byte advCount;
	private byte ultimateCount;
	public BlockCondenserMK2(int var1)
	{
		super(var1, Material.rock);
	}

	public String getTextureFile()
	{
		return mod_EEAA.Terrain;
	}

	/**
	 * Returns the TileEntity used by this block.
	 */
	public TileEntity getBlockEntity()
	{
		return null;
	}

	/**
	 * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
	 * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
	 */
	public boolean isOpaqueCube()
	{
		return false;
	}

	/**
	 * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
	 */
	public boolean renderAsNormalBlock()
	{
		return false;
	}

	/**
	 * The type of render function that is called for this block
	 */
	public int getRenderType()
	{
		return mod_EE.chestModelID;
	}

	public int getLightValue(IBlockAccess var1, int var2, int var3, int var4)
	{
		TileEE var5 = (TileEE)var1.getBlockTileEntity(var2, var3, var4);
		return var5 == null ? lightValue[this.blockID] : var5.getLightValue();
	}

	/**
	 * Lets the block know when one of its neighbor changes. Doesn't know which neighbor changed (coordinates passed are
	 * their own) Args: x, y, z, neighbor blockID
	 */
	public void onNeighborBlockChange(World var1, int var2, int var3, int var4, int var5)
	{
		TileEE var6 = (TileEE)var1.getBlockTileEntity(var2, var3, var4);

		if (var6 == null)
		{
			var1.setBlockWithNotify(var2, var3, var4, 0);
		}
		else
		{
			var6.onNeighborBlockChange(var5);
		}
	}

	/**
	 * Called when the block is placed in the world.
	 */
	public void onBlockPlacedBy(World var1, int var2, int var3, int var4, EntityLiving var5)
	{
		TileEE var6 = (TileEE)var1.getBlockTileEntity(var2, var3, var4);

		if (var6 != null)
		{
			var6.onBlockPlacedBy(var5);
		}
	}

	public float getHardness(int var1)
	{
		switch (var1)
		{
		case 0:
			return 1.5F;

		case 1:
			return 3.5F;

		default:
			return 3.0F;
		}
	}

	/**
	 * Returns the ID of the items to drop on destruction.
	 */
	 public int idDropped(int var1, Random var2, int var3)
	 {
		 return this.blockID;
	 }

	 /**
	  * Returns the quantity of items to drop on block destruction.
	  */
	 public int quantityDropped(Random var1)
	 {
		 return 1;
	 }

	 /**
	  * Determines the damage on the item the block drops. Used in cloth and wood.
	  */
	 public int damageDropped(int var1)
	 {
		 return var1;
	 }

	 /**
	  * A randomly called display update to be able to add particles or other items for display
	  */
	 public void randomDisplayTick(World var1, int var2, int var3, int var4, Random var5)
	 {
		 TileEE var6 = (TileEE)var1.getBlockTileEntity(var2, var3, var4);

		 if (var6 != null)
		 {
			 var6.randomDisplayTick(var5);
		 }
	 }

	 /**
	  * From the specified side and block metadata retrieves the blocks texture. Args: side, metadata
	  */
	 public int getBlockTextureFromSideAndMetadata(int var1, int var2)
	 {
		 return ((TileEE)this.getBlockEntity(var2)).getInventoryTexture(var1);
	 }

	 /**
	  * Returns the block texture based on the side being looked at.  Args: side
	  */
	 public int getBlockTextureFromSide(int var1)
	 {
		 return this.getBlockTextureFromSideAndMetadata(var1, 0);
	 }

	 /**
	  * Retrieves the block texture to use based on the display side. Args: iBlockAccess, x, y, z, side
	  */
	 public int getBlockTexture(IBlockAccess var1, int var2, int var3, int var4, int var5)
	 {
		 TileEE var6 = (TileEE)var1.getBlockTileEntity(var2, var3, var4);
		 return var6 == null ? 0 : var6.getTextureForSide(var5);
	 }

	 /**
	  * Called whenever the block is removed.
	  */
	 public void onBlockRemoval(World var1, int var2, int var3, int var4)
	 {
		 int var6;
		 ItemStack var7;
		 float var8;
		 float var9;
		 EntityItem var10;
		 float var11;
		 int var12;
		 float var13;

		 if (var1.getBlockTileEntity(var2, var3, var4) instanceof TileCondenserMK2)
		 {
			 TileCondenserMK2 var14 = (TileCondenserMK2)var1.getBlockTileEntity(var2, var3, var4);

			 if (var14 != null)
			 {
				 if(var14.isActivated())
					 this.changeBlockDeActive(var1, var2, var3, var4);
				 for (var6 = 0; var6 < var14.getSizeInventory(); ++var6)
				 {
					 var7 = var14.getStackInSlot(var6);

					 if (var7 != null)
					 {
						 var8 = this.random.nextFloat() * 0.8F + 0.1F;
						 var9 = this.random.nextFloat() * 0.8F + 0.1F;

						 for (var11 = this.random.nextFloat() * 0.8F + 0.1F; var7.stackSize > 0; var1.spawnEntityInWorld(var10))
						 {
							 var12 = this.random.nextInt(21) + 10;

							 if (var12 > var7.stackSize)
							 {
								 var12 = var7.stackSize;
							 }

							 var7.stackSize -= var12;
							 var10 = new EntityItem(var1, var2 + var8, var3 + var9, var4 + var11, new ItemStack(var7.itemID, var12, var7.getItemDamage()));
							 var13 = 0.05F;
							 var10.motionX = (float)this.random.nextGaussian() * var13;
							 var10.motionY = (float)this.random.nextGaussian() * var13 + 0.2F;
							 var10.motionZ = (float)this.random.nextGaussian() * var13;

							 if (var7.hasTagCompound())
							 {
								 var10.item.setTagCompound((NBTTagCompound)var7.getTagCompound().copy());
							 }
						 }
					 }
				 }
			 }
		 }
		 super.onBlockRemoval(var1, var2, var3, var4);
	 }

	 /**
	  * Called whenever the block is added into the world. Args: world, x, y, z
	  */
	 public void onBlockAdded(World var1, int var2, int var3, int var4)
	 {
		 super.onBlockAdded(var1, var2, var3, var4);

		 TileEE var5 = (TileEE)EEProxy.getTileEntity(var1, var2, var3, var4, TileEE.class);

		 if (var5 != null)
		 {
			 var5.setDefaultDirection();
			 if(var5 instanceof TileCondenserMK2 && this.countAEGUBlock(var1, var2, var3, var4))
			 {
				 ((TileCondenserMK2) var5).setActivateState(true);
				 ((TileCondenserMK2) var5).setBlockAEGUCount(blockCount);
				 ((TileCondenserMK2) var5).setAdvAEGUcount(advCount);
				 ((TileCondenserMK2) var5).setUltimateAEGUCount(ultimateCount);
				 this.changeBlockActive(var1, var2, var3, var4);
			 }
		 }
	 }
		private void changeBlockActive(World world, int tileX, int tileY, int TileZ)
		{
			boolean even;
			for(int i = -1;i<2;i++)
				for(int j = -1;j<2;j++)
					for(int k = -1;k<2;k++)
					{
						if(mod_EEAA.blockAEGU.blockID == world.getBlockId(tileX + i, tileY + j, TileZ + k))
						{
							even = world.getBlockMetadata(tileX + i, tileY + j, TileZ + k) % 2 == 0;
							if(even)
								world.setBlockMetadata(tileX + i, tileY + j, TileZ + k, world.getBlockMetadata(tileX + i, tileY + j, TileZ + k) + 1);
						}
					}
		}
		private void changeBlockDeActive(World world, int tileX, int tileY, int TileZ)
		{
			boolean odd;
			for(int i = -1;i<2;i++)
				for(int j = -1;j<2;j++)
					for(int k = -1;k<2;k++)
					{
						if(mod_EEAA.blockAEGU.blockID == world.getBlockId(tileX + i, tileY + j, TileZ + k))
						{
							odd = world.getBlockMetadata(tileX + i, tileY + j, TileZ + k) % 2 == 1;
							if(odd)
								world.setBlockMetadata(tileX + i, tileY + j, TileZ + k, world.getBlockMetadata(tileX + i, tileY + j, TileZ + k) - 1);
						}
					}
		}
		private boolean countAEGUBlock(World world, int x,int y, int z)
		{
			this.blockCount = 0;
			this.advCount = 0;
			this.ultimateCount = 0;
			for(int i = -1;i<2;i++)
				for(int j = -1;j<2;j++)
					for(int k = -1;k<2;k++)
					{
						if(mod_EEAA.blockAEGU.blockID == world.getBlockId(x + i, y + j, z + k) &&  world.getBlockMetadata(x + i, y + j, z + k) % 2 == 0)
						{
							this.blockCount++;
							if(world.getBlockMetadata(x + i, y + j, z + k) == 2/* || world.getBlockMetadata(x + i, y + j, z + k) == 3*/)
								this.advCount++;
							else if(world.getBlockMetadata(x + i, y + j, z + k) == 4/* || world.getBlockMetadata(x + i, y + j, z + k) == 5*/)
								this.ultimateCount++;
						}
					}
			if(this.blockCount > 24)
				return true;
			else return false;
		}
	 /**
	  * Called upon block activation (left or right click on the block.). The three integers represent x,y,z of the
	  * block.
	  */
	 public boolean blockActivated(World var1, int var2, int var3, int var4, EntityPlayer var5)
	 {
		 if (var5.isSneaking())
		 {
			 return false;
		 }
		 else
		 {
			 var5.openGui(mod_EEAA.getInstance(), mod_EEAA.CondenserMK2Gui, var1, var2, var3, var4);
			 return true;
		 }
	 }
	 public void addCreativeItems(ArrayList itemList)
	 {
		 itemList.add(new ItemStack(this, 1, 0));
	 }
	 public TileEntity getBlockEntity(int var1)
	 {
		 return new TileCondenserMK2();
	 }

}
