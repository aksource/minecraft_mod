package ee_aa;

import net.minecraft.src.ItemStack;

//カスタムEMCを設定したいアイテム用インターフェース。EEMaps2のregisterCustomableEMCItemで登録すること。
public interface ICustomableEMCItem {
	//錬成時に要求されるEMC
	int getEMCForCreating(ItemStack itemStack);
	//錬成盤に溶かした際に得られるEMC
	int getEMCForMelting(ItemStack itemStack);
	//錬成できるかどうか
	boolean canCreatingFromEMC(ItemStack itemStack);
	//EMCとして溶かせるかどうか
	boolean canMeltingToEMC(ItemStack itemStack);
	
	//ItemのshiftedIndexを返すこと。
	int getID();
}
