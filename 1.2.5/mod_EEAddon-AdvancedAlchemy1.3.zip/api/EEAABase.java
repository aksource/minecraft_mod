package net.minecraft.src.ee_aa;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.ItemStack;
import net.minecraft.src.ModLoader;
import net.minecraft.src.ee.EEBase;

public class EEAABase {
	
	//ItemStackがクラインの星かどうか判定。
	public static boolean isKleinStar(ItemStack itemStack) {
		return isKleinStar(itemStack.itemID);
	}
	
	//Item IDがクラインの星かどうか判定。
	public static boolean isKleinStar(int itemID) {
		return EEBase.isKleinStar(itemID);
	}
	
	//ItemStackがクラインの星だった時のクラインの星のランク
	public static int getKleinLevel(ItemStack itemStack) {
		return getKleinLevel(itemStack.itemID);
	}
	
	//Itemがクラインの星だった時のクラインの星のランク
	public static int getKleinLevel(int itemID) {
		return EEBase.getKleinLevel(itemID);
	}
	
	//クラインの星にEMCの値を加える。
    public static boolean addKleinStarPoints(ItemStack kleinStar, int points) {
    	return EEBase.addKleinStarPoints(kleinStar, points);
    }
    
	//クラインの星からEMCの値を引く。
    public static boolean takeKleinStarPoints(ItemStack kleinStar, int points) {
    	return EEBase.takeKleinStarPoints(kleinStar, points, ModLoader.getMinecraftInstance().theWorld);
    }
    
    //インベントリにあるクラインの星を走査してEMCの値を引く。
    public static boolean consumeKleinStarPoint(EntityPlayer entityPlayer, int points) {
    	return EEBase.consumeKleinStarPoint(entityPlayer, points);
    }
}
