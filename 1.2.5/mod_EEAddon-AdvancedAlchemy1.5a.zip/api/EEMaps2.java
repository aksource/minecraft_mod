package ee_aa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.minecraft.src.CraftingManager;
import net.minecraft.src.IRecipe;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.ModLoader;
import net.minecraft.src.ShapedRecipes;
import net.minecraft.src.ShapelessRecipes;
import net.minecraft.src.mod_EEAA;
import net.minecraft.src.forge.oredict.ShapedOreRecipe;
import net.minecraft.src.forge.oredict.ShapelessOreRecipe;
import ee.EEMaps;
import ee.EEMergeLib;

public class EEMaps2
{
	public static final HashMap<Integer, Integer> metaMappings = new HashMap<>();

	public static final HashMap<IdMetaPair, Integer> alchemicalValues = new HashMap<>();

	public static final Map<Integer, Integer> emcBlackListMap = new HashMap<Integer, Integer>();

	public static final Map<IdMetaPair, Integer> emc4CreatingMap = new HashMap<>();

	public static final Map<IdMetaPair, Integer> emc4MeltingMap = new HashMap<>();

	public static int getEMC(ItemStack itemStack)
	{
		if(itemStack == null) return 0;

		if (itemStack.getItem() instanceof IKleinItem) {
			return getEMC(itemStack.itemID, 0);
		}

		if(getEMC(itemStack.itemID, itemStack.getItemDamage()) == 0)
		{
			if(getEMC(itemStack.itemID) > 0 && itemStack.isItemStackDamageable())
				return (int)(getEMC(itemStack.itemID) * ((float)(itemStack.getMaxDamage() - itemStack.getItemDamage()) / (float)itemStack.getMaxDamage()));
			else
				return 0;
		}

		return getEMC(itemStack.itemID, itemStack.getItemDamage());
	}

	public static int getEMC(int id)
	{
		return getEMC(id, 0);
	}

	public static int getEMC(int id, int meta)
	{
		IdMetaPair idMetaPair = new IdMetaPair(id, meta);
		return getEMC(idMetaPair);
	}

	public static int getEMC(IdMetaPair idMetaPair) {
		if (alchemicalValues.containsKey(idMetaPair)) {
			return alchemicalValues.get(idMetaPair);
		}
		return 0;
	}

	public static int getEMCForMelting(int id, int meta) {
		return getEMCForMelting(new ItemStack(id, 1, meta));
	}

	//溶かすときのEMCを取得。
	public static int getEMCForMelting(ItemStack itemStack) {
		if (itemStack == null) {
			return 0;
		}

		if (itemStack.getItem() instanceof ICustomableEMCItem) {
			return (((ICustomableEMCItem)itemStack.getItem()).canMeltingToEMC(itemStack)) ? ((ICustomableEMCItem)itemStack.getItem()).getEMCForMelting(itemStack) : 0;
		}

		IdMetaPair idMetaPair = new IdMetaPair(itemStack.itemID, itemStack.getItemDamage());
		IdMetaPair idMetaPair0 = new IdMetaPair(itemStack.itemID, 0);
		if (emc4MeltingMap.containsKey(idMetaPair)) {
			return emc4MeltingMap.get(idMetaPair);
		}

		if (emc4MeltingMap.containsKey(idMetaPair0)) {
			return emc4MeltingMap.get(idMetaPair0);
		}

		return getEMC(itemStack);
	}


	public static int getEMCForCreating(int id, int meta) {
		return getEMCForCreating(new ItemStack(id, 1, meta));
	}

	//生成するときのEMCを取得。
	public static int getEMCForCreating(ItemStack itemStack) {
		if (itemStack == null) {
			return 0;
		}

		if (itemStack.getItem() instanceof ICustomableEMCItem) {
			return (((ICustomableEMCItem)itemStack.getItem()).canCreatingFromEMC(itemStack)) ? ((ICustomableEMCItem)itemStack.getItem()).getEMCForCreating(itemStack) : 0;
		}

		IdMetaPair idMetaPair = new IdMetaPair(itemStack.itemID, itemStack.getItemDamage());
		IdMetaPair idMetaPair0 = new IdMetaPair(itemStack.itemID, 0);
		if (emc4CreatingMap.containsKey(idMetaPair)) {
			return emc4CreatingMap.get(idMetaPair);
		}

		if (emc4CreatingMap.containsKey(idMetaPair0)) {
			return emc4CreatingMap.get(idMetaPair0);
		}

		return getEMC(itemStack);
	}

	//レシピからの自動EMC登録メソッド。便利
	public static void addEMCToItemStackFromRecipes(ItemStack outputItem) {
		if (!isRegisterableItem(outputItem)) {
			mod_EEAA.logWarningForDebug(String.format("[EEAA]%s is not added EMC.", outputItem.getItemNameandInformation().get(0)));
			return;
		}
		@SuppressWarnings("unchecked")
		List<IRecipe> recipeList = CraftingManager.getInstance().getRecipeList();
		for (IRecipe recipe : recipeList) {
			ItemStack recipeOutput = recipe.getRecipeOutput();
			if (recipeOutput != null && outputItem.isItemEqual(recipeOutput)) {
				List<ItemStack> recipeInput = null;
				if (recipe instanceof ShapedRecipes) {
					ItemStack[] recipeitems = ModLoader.getPrivateValue(ShapedRecipes.class, (ShapedRecipes)recipe, 2);
					recipeInput = Arrays.asList(recipeitems);
					addEMCFromRecipe(outputItem, recipeInput);
				} else if (recipe instanceof ShapelessRecipes) {
					recipeInput = ModLoader.getPrivateValue(ShapelessRecipes.class, (ShapelessRecipes)recipe, 1);
					addEMCFromRecipe(outputItem, recipeInput);
				} else if (recipe instanceof ShapedOreRecipe) {
					Object[] recipeobjects = ModLoader.getPrivateValue(ShapedOreRecipe.class, (ShapedOreRecipe)recipe, 3);
					List<Object> inputObjects = Arrays.asList(recipeobjects);
					addEMCFromOreRecipe(outputItem, inputObjects);
				} else if (recipe instanceof ShapelessOreRecipe) {
					List<Object> inputObjects = ModLoader.getPrivateValue(ShapelessOreRecipe.class, (ShapelessOreRecipe)recipe, 1);
					addEMCFromOreRecipe(outputItem, inputObjects);
				}
			}
		}
	}

	//ICustomableEMCItemの登録。非推奨。
	@Deprecated
	public static void registerCustomableEMCItem(ICustomableEMCItem item) {
			addEMC(item.getID(), 0);
	}

	//ICustomableEMCItemの登録。
	public static void registerCustomableEMCItem(ICustomableEMCItem item, int meta) {
			addEMC(item.getID(), meta, 0);
	}

	//錬成盤等で溶かす際のEMCを設定。
	public static void addEMCForMelting(ItemStack itemStack, int value) {
		if (itemStack != null) {
			addEMCForMelting(itemStack.itemID, itemStack.getItemDamage(), value);
		}
	}

	//錬成盤等で溶かす際のEMCを設定。
	public static void addEMCForMelting(int id, int value) {
		addEMCForMelting(id, 0, value);
	}

	//錬成盤等で溶かす際のEMCを設定。
	public static void addEMCForMelting(int id, int meta, int value) {
		if (Item.itemsList[id] == null) {
			return;
		}
		IdMetaPair idMetaPair = new IdMetaPair(id, meta);
		emc4MeltingMap.put(idMetaPair, value);
	}

	//錬成盤等で生成する際のEMCを設定。
	public static void addEMCForCreating(ItemStack itemStack, int value) {
		if (itemStack != null) {
			addEMCForCreating(itemStack.itemID, itemStack.getItemDamage(), value);
		}
	}

	//錬成盤等で生成する際のEMCを設定。
	public static void addEMCForCreating(int id, int value) {
		addEMCForCreating(id, 0, value);
	}

	//錬成盤等で生成する際のEMCを設定。
	public static void addEMCForCreating(int id, int meta, int value) {
		if (Item.itemsList[id]== null ) {
			return;
		}
		IdMetaPair idMetaPair = new IdMetaPair(id, meta);
		emc4CreatingMap.put(idMetaPair, value);
		addEMC(idMetaPair, 0);
	}

	//EMCを設定。
	public static void addAlchemicalValue(ItemStack itemstack, int value)
	{
		if (itemstack != null) {
			addEMC(itemstack.itemID, itemstack.getItemDamage(), value);
		}
	}

	//EMCを設定。
	public static void addEMC(int id, int value)
	{
		addEMC(id, 0, value);
	}

	//EMCを設定。
	public static void addEMC(int id, int meta, int value)
	{
		if (Item.itemsList[id]== null ) {
			return;
		}
		IdMetaPair idMetaPair = new IdMetaPair(id, meta);
		addEMC(idMetaPair, value);
	}

	//EMCを設定。
	public static void addEMC(IdMetaPair idMetaPair, int value) {
		mod_EEAA.logFineForDebug(String.format("[EEAA] Add EMC Value %d to ID:%d META:%d", value, idMetaPair.getId(), idMetaPair.getMeta()));
		alchemicalValues.put(idMetaPair, value);
	}

	//EMCをレシピリストから設定。
	public static void addEMCFromRecipes(List<IRecipe> recipes, int times) {
		List<ItemStack> recipeInput = null;
		String className = null;
		List<IRecipe> nonEMCRecipe = new ArrayList<>();
		for(IRecipe recipe : recipes) {
			if(recipe.getRecipeOutput() == null) continue;
			className = recipe.getClass().getName();
			mod_EEAA.logFineForDebug(String.format("[EEAA]Check EMC value of %s (%d)", recipe.getRecipeOutput().getItemNameandInformation().get(0), times));
			if (EEMaps2.isRegisterableItem(recipe.getRecipeOutput())) {
				mod_EEAA.logFineForDebug("[EEAA]" + recipe.getRecipeOutput().getItemNameandInformation().get(0) + " has already EMC value.");
				continue;
			} else if (emcBlackListMap.containsKey(recipe.getRecipeOutput().itemID) && emcBlackListMap.get(recipe.getRecipeOutput().itemID) == recipe.getRecipeOutput().getItemDamage()) {
				mod_EEAA.logFineForDebug("[EEAA]" + recipe.getRecipeOutput().getItemNameandInformation().get(0) + " is in EMC BlackList.");
				continue;
			} else if (recipe instanceof ShapedRecipes) {
				ItemStack[] recipeitems = ModLoader.getPrivateValue(ShapedRecipes.class, (ShapedRecipes)recipe, 2);
				recipeInput = Arrays.asList(recipeitems);
				if(!addEMCFromRecipe(recipe.getRecipeOutput(), recipeInput)) {
					nonEMCRecipe.add(recipe);
				}
			} else if (recipe instanceof ShapelessRecipes) {
				recipeInput = ModLoader.getPrivateValue(ShapelessRecipes.class, (ShapelessRecipes)recipe, 1);
				if(!addEMCFromRecipe(recipe.getRecipeOutput(), recipeInput)) {
					nonEMCRecipe.add(recipe);
				}
			} else if (recipe instanceof ShapedOreRecipe) {
				Object[] recipeobjects = ModLoader.getPrivateValue(ShapedOreRecipe.class, (ShapedOreRecipe)recipe, 3);
				List<Object> inputObjects = Arrays.asList(recipeobjects);
				if(!addEMCFromOreRecipe(recipe.getRecipeOutput(), inputObjects)) {
					nonEMCRecipe.add(recipe);
				}
			} else if (recipe instanceof ShapelessOreRecipe) {
				List<Object> inputObjects = ModLoader.getPrivateValue(ShapelessOreRecipe.class, (ShapelessOreRecipe)recipe, 1);
				if(!addEMCFromOreRecipe(recipe.getRecipeOutput(), inputObjects)) {
					nonEMCRecipe.add(recipe);
				}
			} else if (className.equals("ic2.common.AdvRecipe") || className.equals("ic2.common.AdvShapelessRecipe")) {
				try {
					ItemStack[] recipeitems = (ItemStack[]) Class.forName(className).getField("input").get(recipe);
					recipeInput = Arrays.asList(recipeitems);
					if(!addEMCFromRecipe(recipe.getRecipeOutput(), recipeInput)) {
						nonEMCRecipe.add(recipe);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (!nonEMCRecipe.isEmpty() && times < mod_EEAA.emcSettingTimes) {
			times++;
			addEMCFromRecipes(nonEMCRecipe, times);
			nonEMCRecipe.clear();
		}
	}

	//耐久値を別のパラメータとして利用しているアイテムの登録。
	public static void addChargedItem(int itemID) {
		EEMaps.addChargedItem(itemID);
	}

	//耐久値を別のパラメータとして利用しているアイテムの登録。
	public static void addChargedItem(Item item) {
		addChargedItem(item.shiftedIndex);
	}

	//耐久値を別のパラメータとして利用しているアイテムの登録。
	public static void addChargedItem(ItemStack itemStack) {
		EEMaps.addChargedItem(itemStack);
	}

	//クライン系アイテムの統合レシピ？の登録。
	public static void addKleinForMerge(Item item) {
        EEAAMergeLib.addMergeOnCraft(item);
        EEMergeLib.mergeOnCraft.remove(item.shiftedIndex);
	}

	private static boolean addEMCFromRecipe(ItemStack output, List<ItemStack> inputs) {
		if(inputs != null) {
			int sumEMC = 0;
			mod_EEAA.logFineForDebug("[EEAA]Start setting EMC to " + output.getItemNameandInformation().get(0));
			for (ItemStack item : inputs) {
				if(item == null) continue;
				if(item.getItemDamage() < 0) {
					item = new ItemStack(item.itemID, item.stackSize, 0);
				}
				if(item.getItem() instanceof IKleinItem && item.getItemDamage() == 1) {
					int chargedEMC = ((IKleinItem)item.getItem()).getMaxPoints(item);
					mod_EEAA.logFineForDebug(String.format("[EEAA]Get %s's EMC : %d", item.getItemNameandInformation().get(0), getEMCForCreating(item) + chargedEMC));
					sumEMC += getEMCForCreating(item) + chargedEMC;
				} else if (getEMCForCreating(item) > 0) {
					mod_EEAA.logFineForDebug(String.format("[EEAA]Get %s's EMC : %d", item.getItemNameandInformation().get(0), getEMCForCreating(item)));
					sumEMC += getEMCForCreating(item);
				} else {
					mod_EEAA.logFineForDebug("[EEAA]" + item .getItemNameandInformation().get(0) + " doesn't have EMC. Canceled setting.");
					return false;
				}
			}
			sumEMC /= output.stackSize;
			if (sumEMC > 0) {
				mod_EEAA.logFineForDebug(String.format("[EEAA]Set %s's EMC : %d", output.getItemNameandInformation().get(0), sumEMC));
				addEMC(output.itemID, output.getItemDamage(), sumEMC);
			}
			return true;
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	private static boolean addEMCFromOreRecipe(ItemStack output, List<Object> inputs) {
		if(inputs != null) {
			int sumEMC = 0;
			mod_EEAA.logFineForDebug("[EEAA]Start setting EMC to " + output.getItemNameandInformation().get(0));
			ItemStack oreItem = null;
			for (Object obj : inputs) {
				if(obj == null) continue;
				else if(obj instanceof ItemStack) {
					oreItem = (ItemStack)obj;
				} else {
					oreItem = ((ArrayList<ItemStack>)obj).get(0);
				}

				if (oreItem != null && getEMCForCreating(oreItem) > 0) {
					mod_EEAA.logFineForDebug(String.format("[EEAA]Get %s's EMC : %d", oreItem.getItemNameandInformation().get(0), getEMCForCreating(oreItem)));
					sumEMC += getEMCForCreating(oreItem);
				} else {
					mod_EEAA.logFineForDebug("[EEAA]" + oreItem .getItemNameandInformation().get(0) + " doesn't have EMC. Canceled setting.");
					return false;
				}
			}
			sumEMC /= output.stackSize;
			mod_EEAA.logFineForDebug(String.format("[EEAA]Set %s's EMC : %d", output.getItemNameandInformation().get(0), sumEMC));
			addEMC(output.itemID, output.getItemDamage(), sumEMC);
			return true;
		}
		return false;
	}

	private static boolean isRegisterableItem(ItemStack itemStack) {
		if (itemStack == null) {
			return false;
		}

		if (itemStack.getItem() instanceof ICustomableEMCItem) {
			return false;
		}

		IdMetaPair idMetaPair = new IdMetaPair(itemStack.itemID, itemStack.getItemDamage());
		IdMetaPair idMetaPair0 = new IdMetaPair(itemStack.itemID, 0);
		if (emc4CreatingMap.containsKey(idMetaPair) || emc4CreatingMap.containsKey(idMetaPair0) || emc4MeltingMap.containsKey(idMetaPair) || emc4MeltingMap.containsKey(idMetaPair0)) {
			return false;
		}

		return getEMCForCreating(itemStack) == 0;
	}
}
