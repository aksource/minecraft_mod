package infinitychest;

import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class InfinityChestSlot extends Slot
{
	private boolean getSlot;
	private boolean putSlot;
	public InfinityChestSlot(IInventory inv, int index, int x, int y, boolean get, boolean put)
	{
		super(inv, index, x, y);
		getSlot = get;
		putSlot = put;
	}

	@Override
	public boolean isItemValid(ItemStack par1ItemStack)
	{
		return putSlot;
	}

}
