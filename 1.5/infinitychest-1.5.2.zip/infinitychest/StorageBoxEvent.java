package infinitychest;

import java.lang.reflect.Field;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.src.BaseMod;
import net.minecraft.world.World;
import net.minecraftforge.event.Event;
import net.minecraftforge.event.ForgeSubscribe;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;

/**
 * Created by A.K. on 15/01/31.
 */
public class StorageBoxEvent {

	public static Item getStorageBox() {
		Item item = null;
		try {
			Class<BaseMod> c = (Class<BaseMod>) Class.forName("net.minecraft.storagebox.mod_StorageBox");
			Field f = c.getField("itemStBox");
			item = (Item) f.get(null);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return  item;
	}

//storageBox api start

    @ForgeSubscribe
    public void onSBActivated(PlayerInteractEvent event) {
        int activatedBlock = event.entityPlayer.worldObj.getBlockId(event.x, event.y, event.z);
        if (event.action == PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK && activatedBlock == InfinityChest.infinityChest.blockID) {
            InfinityChestTile tile = (InfinityChestTile)event.entityPlayer.worldObj.getBlockTileEntity(event.x, event.y, event.z);
            ItemStack itemStack = event.entityPlayer.getCurrentEquippedItem();
            if (tile != null && itemStack != null && itemStack.getItem().equals(CE.itemStorageBox) && itemStack.stackSize == 1) {
                if(onStorageBox(event.entityPlayer.worldObj, event.entityPlayer, tile, itemStack)) {
                    event.useBlock = Event.Result.DENY;
                    event.useItem = Event.Result.DENY;
                }
            }
        }
    }

    private static int storageLimit = InfinityChest.StorageBoxReceiptMax;
    private boolean onStorageBox(World world, EntityPlayer player, InfinityChestTile tile, ItemStack stack)
    {
        NBTTagCompound nbt = stack.getTagCompound();
        boolean flag = true;
        int result = 0;
        int size = 0;
        if(nbt == null || nbt.getInteger("StorageSize") <= 0)
        {
            if(!tile.hasStack() || !isItemValid(tile.getStack())) return false;
            if(nbt == null) nbt = new NBTTagCompound();
            int id 		= tile.getStack().getItem().itemID;
            int damage 	= tile.getStack().getItemDamage();
            size 	= 0;
            nbt.setInteger("StorageItem", id);
            nbt.setInteger("StorageDamage", damage);
            nbt.setInteger("StorageSize", 0);
//            Item item = Item.getItemById(id);
            result = onItemStack(world, player, tile, new ItemStack(id, size, damage), 1);
        }else{
            int id 		= nbt.getInteger("StorageItem");
            int damage 	= nbt.getInteger("StorageDamage");
            size 	= nbt.getInteger("StorageSize");
            if(size <= 0) return false;
            int limit = calcLimit(size);
            if(limit > storageLimit) limit = storageLimit;
//            Item item = Item.getItemById(id);
            result = onItemStack(world, player, tile, new ItemStack(id, size, damage), limit);
        }
        if(size == result) return false;
        nbt.setInteger("StorageSize", result);
        stack.setTagCompound(nbt);
        return true;
    }

    private static boolean isItemValid(ItemStack itemstack)
    {
        return !itemstack.getItem().equals(CE.itemStorageBox) && !itemstack.hasTagCompound() && !itemstack.isItemStackDamageable();
    }

    private static int calcLimit(int value)
    {
        if(value >= 10000000) return 100000000;
        if(value >= 1000000) return 10000000;
        if(value >= 100000) return 1000000;
        if(value >= 10000) return 100000;
        if(value >= 1000) return 10000;
        return 1000;
    }

    //nbttagにセットする数を返す
    private int onItemStack(World world, EntityPlayer player, InfinityChestTile tile
            , ItemStack substance, int limit)
    {
        int size = substance.stackSize;
        if(player.isSneaking())
        {
            //アイテム投入
            int min = (player.getCurrentEquippedItem().getItem().equals(CE.itemStorageBox) && size > 1) ? 1: 0;
            substance.stackSize -= min;
            int result = tile.addStack(substance);
            if(result + min < size)
            {
                world.playSoundAtEntity(player, "random.pop", 0.5F, 1.4F);
            }
            size = result + min;
        }else{
            //アイテム取り出し
            int result = tile.decStack(substance, limit);
            if(result > 0)
            {
                world.playSoundAtEntity(player, "random.pop", 0.5F, 1.0F);
            }
            size += result;
        }
        return size;
    }

}
