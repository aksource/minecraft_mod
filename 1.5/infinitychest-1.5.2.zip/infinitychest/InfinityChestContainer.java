package infinitychest;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class InfinityChestContainer extends Container
{
	private InfinityChestTile chest;
	private InventoryPlayer playerInventory;
	private IInventory guiInventory = new InventoryBasic("slots", false, 3);
	private static final int GUI_SLOT_INDEX = 1;

	public InfinityChestContainer(IInventory plInv, IInventory tileInv)
	{
		chest = (InfinityChestTile)tileInv;
		chest.setContainer(this);
		playerInventory = (InventoryPlayer)plInv;
		int y;
		int x;

		this.addSlotToContainer(new InfinityChestSlot(chest, 0, 12, 21, false, false));
		this.addSlotToContainer(new InfinityChestSlot(chest, 1, 80, 63, true, true));
		this.addSlotToContainer(new InfinityChestSlot(guiInventory, GUI_SLOT_INDEX, 134, 63, true, false));
		changeSlot();

		for (y = 0; y < 3; ++y)
		{
			for (x = 0; x < 9; ++x)
			{
				this.addSlotToContainer(new Slot(plInv, x + y * 9 + 9, 8 + x * 18, 84 + y * 18));
			}
		}

		for (x = 0; x < 9; ++x)
		{
			this.addSlotToContainer(new Slot(plInv, x, 8 + x * 18, 142));
		}
	}

	//outスロットの更新
	protected void changeSlot()
	{
		if(!chest.hasStack())
		{
			guiInventory.setInventorySlotContents(GUI_SLOT_INDEX, null);
			return;
		}
		ItemStack chestStack = chest.getStack();
		int maxStack = chestStack.getMaxStackSize();
		ItemStack slot2 = chestStack.copy();
		if(slot2.stackSize >= maxStack)
		{
			slot2.stackSize = maxStack;
		}
		guiInventory.setInventorySlotContents(GUI_SLOT_INDEX, slot2);
	}
    @Override
	public boolean canInteractWith(EntityPlayer player)
	{
		return this.chest.isUseableByPlayer(player);
	}

	//スロットクリック時に呼び出される
	@Override
	public ItemStack slotClick(int slot, int mouse, int isShift, EntityPlayer player)
	{
		if(mouse > 1 || mouse < 0) return null;
		if(slot == 0) return debugmode(mouse, isShift, player);	//スロット0は無効
		ItemStack stack = player.inventory.getItemStack();
		if(stack == null)	//手持ちのアイテムがない場合
		{
			if(slot == 1) return null;	//スロット1は無効
			if(slot == 2)
			{
				if(isShift != 1)
				{
					return outPickup(mouse, player.inventory);	//outからピックアップ
				}else{
					return addInventory(player.inventory);	//outからインベントリへ
				}
			}
			if(isShift  != 1 || slot < 0)
			{
				return super.slotClick(slot, mouse, isShift, player);	//既存処理
			}else{
				return addChest(slot, player.inventory);	//インベントリから投入
			}
		}else{	//手持ちがある場合
			if(slot == 1)
			{
				if(isShift != 1)
				{
					return addChest(stack, mouse, player.inventory);	//手持ちを投入
				}else{
					return addChest(stack, player.inventory);	//インベントリからまとめて投入
				}
			}
			if(slot == 2) return null;	//スロット2は無効
			if(isShift != 1|| slot < 0)
			{
				return super.slotClick(slot, mouse, isShift, player);	//既存処理
			}else{
				return addInventory(stack, player.inventory);	//インベントリにまとめて取り出し
			}
		}
	}

	//outスロットのアイテムを持つ(nostack slot2 noshift)
	protected ItemStack outPickup(int mouse, InventoryPlayer playerInventory)
	{
		ItemStack slotStack = guiInventory.getStackInSlot(1);
		if(slotStack == null) return null;
		int size = slotStack.stackSize;
		if(mouse == 1)
		{
			size = (size & 1) + (size >> 1);
		}
		playerInventory.setItemStack(slotStack.splitStack(size));
		ItemStack result = chest.decSize(size);
		changeSlot();
		return result;
	}

	//手持ちを投入(stack slot1 noshift)
	protected ItemStack addChest(ItemStack stack, int mouse, InventoryPlayer playerInventory)
	{
		if(!chest.isStackable(stack)) return null;
		if(mouse == 1)
		{
			ItemStack copy = stack.copy();
			copy.stackSize = 1;
			if(addChest(copy) == null)
			{
				playerInventory.setItemStack(decStack(stack, 1));
				changeSlot();
			}
			return null;
		}
		playerInventory.setItemStack(addChest(stack));
		return null;
	}

	//インベントリからまとめて投入(stack slot1 shift)
	protected ItemStack addChest(ItemStack stack, InventoryPlayer playerInventory)
	{
		if(addChest(stack) == null) playerInventory.setItemStack(null);
		for(int i = 0; i < 36; i++)
		{
			Slot cs = (Slot)inventorySlots.get(i + 3);
			ItemStack slotStack = cs.getStack();
			if(!chest.isItemEqual(slotStack)) continue;
			if(addChest(i + 3, playerInventory) != null ) return null;
		}
		return null;
	}

	//インベントリから投入(nostack slot3-38 shift)
	protected ItemStack addChest(int slot, InventoryPlayer playerInventory)
	{
		Slot cs = (Slot)inventorySlots.get(slot);
		ItemStack slotStack = cs.getStack();
		ItemStack result = null;
		if(slotStack != null) result = addChest(slotStack);
		cs.putStack(result);
		changeSlot();
		return result;
	}

	//stackを投入
	protected ItemStack addChest(ItemStack stack)
	{
		if(!chest.isStackable(stack)) return stack;
		if(!chest.hasStack())
		{
			chest.setStack(stack);
			changeSlot();
			return null;
		}
		if(chest.getStack().stackSize >= InfinityChestTile.stackLimit) return stack;
		if(!chest.isItemEqual(stack)) return stack;
		ItemStack result = chest.addSize(stack.stackSize);
		int size = (result == null) ? stack.stackSize: result.stackSize;
		ItemStack result2 = decStack(stack, size);
		changeSlot();
		return result2;
	}

	//stackを減らす
	public ItemStack decStack(ItemStack stack, int size)
	{
		stack.stackSize -= size;
		if(stack.stackSize <= 0) stack = null;
		return stack;
	}

	//outからインベントリへ(nostack slot2 shift)
	protected ItemStack addInventory(InventoryPlayer playerInventory)
	{
		ItemStack stack = guiInventory.getStackInSlot(1);
		if(stack == null) return null;
		int sizeA = stack.stackSize;
		ItemStack result = addInventory(stack);
		int size = (result == null) ? 0: result.stackSize;
		chest.decSize(sizeA - size);
		changeSlot();
		return result;
	}

	//インベントリにまとめて取り出し(stack slot3-38 shift)
	protected ItemStack addInventory(ItemStack stack, InventoryPlayer playerInventory)
	{
		if(!chest.isItemEqual(stack)) return null;
		chest.getStack().stackSize += stack.stackSize;
		playerInventory.setItemStack(null);
		ItemStack result = addInventory(chest.getStack());
		chest.setStack(result);
		changeSlot();
		return result;
	}

	//空きプレイヤーインベントリにアイテムを投入
	protected ItemStack addInventory(ItemStack stack)
	{
		if(!chest.isItemEqual(stack)) return stack;
		int stacksize = stack.stackSize;
		for(int i = 0; i < 36; i++)
		{
			if(stacksize <= 0) break;
			Slot cs = (Slot)inventorySlots.get(i + 3);
			ItemStack slotStack = cs.getStack();
			if(slotStack != null && !chest.isItemEqual(slotStack)) continue;
			if(slotStack != null && slotStack.stackSize == slotStack.getMaxStackSize()) continue;
			int size;
			if(slotStack != null)
			{
				size = stack.getMaxStackSize() - slotStack.stackSize;
			}else{
				size = stack.getMaxStackSize();
			}
			if(size <= 0) continue;
			ItemStack putStack = stack.copy();
			putStack.stackSize = (slotStack == null) ? 0: slotStack.stackSize;

			if(stacksize < size)
			{
				size = stacksize;
			}
			putStack.stackSize += size;
			decStack(stack, size);
			stacksize -= size;
			cs.putStack(putStack);
			if(stacksize <= 0)
			{
				stacksize = 0;
				break;
			}
		}
		stack.stackSize = stacksize;
		if(stacksize <= 0) stack = null;
		return stack;//残りのアイテム
	}

	public ItemStack debugmode(int mouse, int isShift, EntityPlayer player)
	{
		if(CE.isDebug() && CE.isCreative(player)
		// && CE.isDebugmode()
		)
		{
			if(mouse == 0)
			{
				chest.addSize((isShift == 1 ? 100000000: 64));
			}else{
				chest.decSize((isShift == 1 ? 100000000: 64));
			}
			changeSlot();
		}
		return null;
	}

	//Guiを閉じた時に呼び出される
	@Override
	public void onCraftGuiClosed(EntityPlayer player)
	{
		super.onCraftGuiClosed(player);
	}

}
