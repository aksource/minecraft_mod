package infinitychest;

import java.util.logging.Logger;

import cpw.mods.fml.common.Loader;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.Init;
import cpw.mods.fml.common.Mod.PostInit;
import cpw.mods.fml.common.Mod.PreInit;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.network.NetworkMod;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.util.MathHelper;
import net.minecraftforge.common.Configuration;
import net.minecraftforge.common.MinecraftForge;


@Mod(modid = "InfinityChest", name = "InfinityChest", version = "152v2", dependencies = "required-after:FML", useMetadata = true)
@NetworkMod(clientSideRequired=true, serverSideRequired=false)
public class InfinityChest
{
	public static int buildNumber = 2;
/*
    1:1.5.2対応
    2:GUIのアイテム描画時に落ちる不具合を修正。
    3:3:鉱石辞書対応処理不具合により、アイテム種別関係なく、投入できてしまう不具合を修正。
    4:StorageBoxとの連携が切れていたので、修正。
*/

	public static int StorageBoxReceiptMax;
    public static boolean doOreNameConvert = true;
    @Mod.Instance("InfinityChest")
	public static InfinityChest instance;

    @SidedProxy(clientSide = "infinitychest.client.ClientProxy", serverSide = "infinitychest.CommonProxy")
    public static CommonProxy proxy;

	public static Block infinityChest;
	public static int blockId = 2500;

    public static boolean isLoadSB;

    public static Logger logger = Logger.getLogger("InfinityChest");

    @PreInit
    public void preInit(FMLPreInitializationEvent event) {
        event.getModMetadata().version = String.format("152-%d", buildNumber);
        Configuration config = new Configuration(
                event.getSuggestedConfigurationFile());
        config.load();
        StorageBoxReceiptMax = config.get(Configuration.CATEGORY_GENERAL, "StorageBoxReceiptMax", 10000000, "Maximum value that can be receipt to StorageBox from InfinityChest. min=1000, max=100000000").getInt();
        StorageBoxReceiptMax = MathHelper.clamp_int(StorageBoxReceiptMax, 1000, 100000000);
        doOreNameConvert = config.get(Configuration.CATEGORY_GENERAL, "doOreNameConvert", true, "Convert Item with Ore Name").getBoolean(true);
        blockId = config.get(Configuration.CATEGORY_BLOCK, "blockId", blockId).getInt();
        config.save();
        //無限チェスト
        infinityChest = new InfinityChestBlock(blockId).setUnlocalizedName("InfinityChest")/*.setTextureName("glass")*/.setCreativeTab(CreativeTabs.tabDecorations);
        GameRegistry.registerBlock(infinityChest, InfinityChestItem.class, "infinitychest");
    }

    @Init
    public void init(FMLInitializationEvent event) {
        NetworkRegistry.instance().registerGuiHandler(this, proxy);
        MinecraftForge.EVENT_BUS.register(new StorageBoxEvent());
        CE.init();
    }

    @PostInit
    public void postInit(FMLPostInitializationEvent event) {
        isLoadSB = Loader.isModLoaded("mod_StorageBox");
        if (isLoadSB) CE.itemStorageBox = StorageBoxEvent.getStorageBox()/*GameRegistry.findItem("net.minecraft.storagebox.mod_StorageBox", "Storage Box")*/;

        LanguageRegistry.addName(infinityChest, "Two Billions Chest");
        LanguageRegistry.instance().addNameForObject(infinityChest, "ja_JP", "20億チェスト");
        LanguageRegistry.instance().addStringLocalization("infinity.chest.container", "Two Billions Chest (Max%s)");
        LanguageRegistry.instance().addStringLocalization("infinity.chest.container", "ja_JP", "20億チェスト (最大%s)");
    }
}