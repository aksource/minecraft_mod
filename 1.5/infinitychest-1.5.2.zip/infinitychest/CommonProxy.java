package infinitychest;

import infinitychest.client.InfinityChestGui;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import cpw.mods.fml.common.network.IGuiHandler;

/**
 * Created by A.K. on 14/06/03.
 */
public class CommonProxy implements IGuiHandler{

    public static int infiGuiID = 1;
    public void registerClientInformation(){}

    @Override
    public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
        if(ID == infiGuiID)
        {
            InfinityChestTile tile = (InfinityChestTile)world.getBlockTileEntity(x, y, z);
            return new InfinityChestContainer(player.inventory, tile);
        }
        return null;
    }

    @Override
    public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
        if(ID == infiGuiID)
        {
            InfinityChestTile tile = (InfinityChestTile)world.getBlockTileEntity(x, y, z);
            return new InfinityChestGui(player.inventory, tile);
        }
        return null;
    }
}
