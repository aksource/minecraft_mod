package infinitychest.client;

import java.util.HashSet;
import java.util.Set;

import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderBlocks;

import org.lwjgl.opengl.GL11;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

//ツンなブロックの方向を修正するクラス
@SideOnly(Side.CLIENT)
public class InfinityRenderBlocks extends RenderBlocks
{
    private static final Set<Block> shouldRotateRenderBlocks = new HashSet<Block>();

    @Override
    public void renderBlockAsItem(Block block, int meta, float brightness) {
        GL11.glPushMatrix();
        if (shouldRotateRenderBlocks.contains(block)) {
            GL11.glRotatef(-90f, 0.0f, 1.0f, 0.0f);//たった一つの冴えたやり方
        }
        super.renderBlockAsItem(block, meta, brightness);
        GL11.glPopMatrix();
    }

    static{
        //ツンなブロックの登録。
        shouldRotateRenderBlocks.add(Block.chest);
        shouldRotateRenderBlocks.add(Block.chestTrapped);
        shouldRotateRenderBlocks.add(Block.enderChest);
        shouldRotateRenderBlocks.add(Block.fence);
        shouldRotateRenderBlocks.add(Block.fenceGate);
        shouldRotateRenderBlocks.add(Block.netherFence);
        shouldRotateRenderBlocks.add(Block.furnaceIdle);
        shouldRotateRenderBlocks.add(Block.dropper);
        shouldRotateRenderBlocks.add(Block.dispenser);
    }
}
