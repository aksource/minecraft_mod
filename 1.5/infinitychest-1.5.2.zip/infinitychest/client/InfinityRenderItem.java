package infinitychest.client;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.RenderEngine;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.item.ItemStack;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class InfinityRenderItem extends RenderItem
{
	@Override
	public void renderItemAndEffectIntoGUI(FontRenderer par1FontRenderer, RenderEngine par2RenderEngine, ItemStack stack, int x, int y)
	{
		if (stack != null && x == 12 && y == 21) return;
		super.renderItemAndEffectIntoGUI(par1FontRenderer, par2RenderEngine, stack, x, y);
	}

}
