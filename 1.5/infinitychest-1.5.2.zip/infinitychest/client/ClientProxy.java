package infinitychest.client;

import cpw.mods.fml.client.registry.ClientRegistry;
import infinitychest.CommonProxy;
import infinitychest.InfinityChestTile;
import net.minecraftforge.common.MinecraftForge;

/**
 * Created by A.K. on 14/06/04.
 */
public class ClientProxy extends CommonProxy{

    @Override
    public void registerClientInformation() {
        ClientRegistry.bindTileEntitySpecialRenderer(InfinityChestTile.class, new InfinityChestRenderer());
        MinecraftForge.EVENT_BUS.register(new RenderChestItemInfo());
    }
}
