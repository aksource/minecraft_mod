package infinitychest.client;

import org.lwjgl.opengl.GL11;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import infinitychest.InfinityChestTile;
import net.minecraft.block.Block;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Icon;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.MinecraftForgeClient;

@SideOnly(Side.CLIENT)
public class InfinityChestRenderer extends TileEntitySpecialRenderer
{
	public static final int GL_RESCALE_NORMAL_EXT = 32826;
	public static final int GL_LIGHTING = 2896;

    private static RenderBlocks renderBlocks;
    protected FontRenderer fontRenderer;
    private ItemStack inChestItemStack;

	public InfinityChestRenderer()
	{
		renderBlocks = new InfinityRenderBlocks();
		fontRenderer = ClientStringUtils.mc.fontRenderer;
	}

	public void render(InfinityChestTile tile, double x, double y, double z, float partialTick)
	{
		if (tile == null) return;

		//中身を表示
		ItemStack stack = tile.getStack();
		if(stack != null)
		{
            if (inChestItemStack == null || !stack.isItemEqual(inChestItemStack) || !ItemStack.areItemStackTagsEqual(stack, inChestItemStack)) {
                inChestItemStack = stack.copy();
                inChestItemStack.stackSize = 1;
            }
			Item item = stack.getItem();
            Block block = null;
			int itemDamage = inChestItemStack/*stack*/.getItemDamage();
			boolean isBlock = stack.getItem() instanceof ItemBlock;
			if (isBlock) {
				block = Block.blocksList[item.itemID];
			}

//			ItemStack itemStack = new ItemStack(item, 1, itemDamage);

			int facing = tile.getBlockMetadata();
			float rotationYaw = 0;
			if (facing == 2) rotationYaw = 180F;
			if (facing == 3) rotationYaw =   0F;
			if (facing == 4) rotationYaw = 270F;
			if (facing == 5) rotationYaw =  90F;
			float shiftX = 0.5F;
			float shiftY = 0.35F;
			float shiftZ = 0.5F;
			float blockScale = 0.6F;
			GL11.glPushMatrix();
			GL11.glDisable(GL_LIGHTING);
			GL11.glEnable(GL_RESCALE_NORMAL_EXT);
			GL11.glTranslated( x,  y,  z);

			GL11.glPushMatrix();
			GL11.glTranslatef(shiftX, shiftY, shiftZ);
			GL11.glScalef(blockScale, blockScale, blockScale);

			GL11.glPushMatrix();
			GL11.glRotatef(rotationYaw, 0.0F, 1.0F, 0.0F);

			EntityItem customitem = new EntityItem(tile.getWorldObj());
			customitem.setEntityItemStack(inChestItemStack/*itemStack*/);
			IItemRenderer customRenderer
				= MinecraftForgeClient.getItemRenderer(inChestItemStack/*itemStack*/, IItemRenderer.ItemRenderType.ENTITY);
			if (customRenderer != null)
			{
                bindTextureByName(inChestItemStack.getItemSpriteNumber() == 0 ? "/terrain.png" : "/gui/items.png");
				customRenderer.renderItem(IItemRenderer.ItemRenderType.ENTITY, inChestItemStack/*itemStack*/
					, renderBlocks, customitem);
			} else if (isBlock && block != null && RenderBlocks.renderItemIn3d(block.getRenderType())) {
			//ブロックの描画
                bindTextureByName("/terrain.png");
				renderBlocks.renderBlockAsItem(block, itemDamage, 1.0F);
			} else {
			//アイテムの描画
                bindTextureByName("/gui/items.png");
                this.renderChestItem(inChestItemStack/*itemStack*/, shiftY);
			}
			GL11.glPopMatrix();
			GL11.glPopMatrix();

			GL11.glDisable(GL_RESCALE_NORMAL_EXT);
			GL11.glEnable(GL_LIGHTING);
			GL11.glPopMatrix();
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		}
	}

	//アイテム描画
	private void renderChestItem(ItemStack itemStack, float shiftY)
	{
		Item item = itemStack.getItem();
		int itemDamage = itemStack.getItemDamage();
		//テクスチャの設定

		Tessellator tessellator = Tessellator.instance;
		float xpos = 0.50F;
		float ypos = 0.25F;
		GL11.glTranslatef(0.0F, -shiftY, 0.0F);
		float blockScale = 1.2F;
		GL11.glScalef(-blockScale, blockScale, blockScale);

		int passes = item.getRenderPasses(itemDamage);
        Icon icon;
		for(int pass = 0; pass < passes; pass++)
		{
            //マルチパスアイコンの取得（getIconFromDamageForRenderPass）
            icon = item.getIcon(itemStack, pass);
            float x1 = icon.getMinU();
            float x2 = icon.getMaxU();
            float y1 = icon.getMinV();
            float y2 = icon.getMaxV();

			//マルチパスレンダーカラーの取得
			int color = item.getColorFromItemStack(itemStack, pass);
			float red  = 1F / 256F * (color >> 16);
			float green= 1F / 256F * ((color & 0xFFFF) >> 8);
			float blue = 1F / 256F * (color & 0xFF);
			GL11.glColor4f(red, green, blue, 1.0F);

			//表面を描写
			GL11.glRotatef(0.0F, 0.0F, 1.0F, 0.0F);
			tessellator.startDrawingQuads();
			tessellator.setNormal(0.0F, 1.0F, 0.0F);
			tessellator.addVertexWithUV(0.0F - xpos, 0.0F - ypos, 0.0D, x1, y2);
			tessellator.addVertexWithUV(1.0F - xpos, 0.0F - ypos, 0.0D, x2, y2);
			tessellator.addVertexWithUV(1.0F - xpos, 1.0F - ypos, 0.0D, x2, y1);
			tessellator.addVertexWithUV(0.0F - xpos, 1.0F - ypos, 0.0D, x1, y1);
			tessellator.draw();

			//裏面を描写
			GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
			tessellator.startDrawingQuads();
			tessellator.setNormal(0.0F, 1.0F, 0.0F);
			tessellator.addVertexWithUV(0.0F - xpos, 0.0F - ypos, 0.0D, x1, y2);
			tessellator.addVertexWithUV(1.0F - xpos, 0.0F - ypos, 0.0D, x2, y2);
			tessellator.addVertexWithUV(1.0F - xpos, 1.0F - ypos, 0.0D, x2, y1);
			tessellator.addVertexWithUV(0.0F - xpos, 1.0F - ypos, 0.0D, x1, y1);
			tessellator.draw();
		}
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
	}

    @Override
	public void renderTileEntityAt(TileEntity tileentity, double x, double y, double z, float partialTick)
	{
		render((InfinityChestTile) tileentity, x, y, z, partialTick);
	}
}
