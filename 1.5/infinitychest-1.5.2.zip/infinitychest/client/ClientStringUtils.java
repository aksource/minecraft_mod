package infinitychest.client;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;

/**
 * Created by A.K. on 15/01/31.
 */
@SideOnly(Side.CLIENT)
public class ClientStringUtils {
    private static final String jpLang = "ja_JP";
    public static Minecraft mc = Minecraft.getMinecraft();

    public static boolean isShift()
    {
        return mc.thePlayer.isSneaking();
    }

    public static boolean isCreative()
    {
        return mc.thePlayer.capabilities.isCreativeMode;
    }

    public static String formatStack(int size)
    {
        return formatStack(size, true, mc.gameSettings.language);
    }

    public static String formatStack(int size, boolean flag)
    {
        return formatStack(size, flag, mc.gameSettings.language);
    }

    public static String formatStack(int size, boolean flag, String lang)
    {
        StringBuilder str = new StringBuilder();
        if(jpLang.equals(lang))
        {
            int n1 = size / 100000000;
            int n2 = size % 100000000 / 10000;
            int n3 = size % 10000;
            if(n1 > 0) str.append(String.format("%d億", n1));
            if(n2 > 0) str.append(String.format("%d万", n2));
            if(n3 > 0) str.append(String.format("%d", n3));
            if(flag)
            {
                str.append("個");
            }
        }else{
            str.append(String.format("%,d", size));
            if(flag)
            {
                str.append(" items");
            }
        }
        return str.toString();
    }

    public static String formatMax(int size)
    {
        StringBuilder str = new StringBuilder();
        if(jpLang.equals(mc.gameSettings.language))
        {
            int n1 = size / 100000000;
            int n2 = size % 100000000 / 10000;
            int n3 = size % 10000;
            if(n1 > 0) str.append(String.format("%d億", n1));
            if(n2 > 0) str.append(String.format("%d万", n2));
            if(n3 > 0) str.append(String.format("%d", n3));
        }else{
            if(size > 1000000000)
            {
                str.append(String.format("%dG", size / 1000000000));
            }
            else if(size > 1000000)
            {
                str.append(String.format("%dM", size / 1000000));
            }
            else if(size > 1000)
            {
                str.append(String.format("%dK", size / 1000));
            }
        }
        return str.toString();
    }

    public static String formatLC(int size)
    {
        int n4 = size / 3456;
        return (n4 > 0) ? String.format("%,d LC", n4).trim(): "";
    }

    public static boolean isDebugmode()
    {
        return mc.gameSettings.showDebugInfo;
    }
}
