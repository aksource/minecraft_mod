package infinitychest.client;

import infinitychest.InfinityChest;
import infinitychest.InfinityChestItem;
import infinitychest.InfinityChestTile;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumMovingObjectType;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import net.minecraftforge.client.event.DrawBlockHighlightEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.ForgeDirection;
import net.minecraftforge.event.ForgeSubscribe;

import org.lwjgl.opengl.GL11;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

/**
 * Created by A.K. on 14/07/11.
 */
@SideOnly(Side.CLIENT)
public class RenderChestItemInfo {
    private final Minecraft mc = Minecraft.getMinecraft();
    @ForgeSubscribe
    public void overlayChestItemInfo(RenderGameOverlayEvent.Text event) {
        EntityPlayer player = Minecraft.getMinecraft().thePlayer;
        ItemStack holdItem = player.getCurrentEquippedItem();
        if (holdItem != null && holdItem.getItem() instanceof InfinityChestItem) {
            renderChestItemInfoOnStatusBar(holdItem, event.partialTicks);
        }
    }

    @ForgeSubscribe
    public void drawChestHighlight(DrawBlockHighlightEvent event) {
        if (event.target.typeOfHit == EnumMovingObjectType.TILE) {
            MovingObjectPosition MOP = event.target;
            World world = event.player.worldObj;
            int blockId = world.getBlockId(MOP.blockX, MOP.blockY, MOP.blockZ);
            TileEntity tileEntity = world.getBlockTileEntity(MOP.blockX, MOP.blockY, MOP.blockZ);
            if (blockId == InfinityChest.infinityChest.blockID && tileEntity instanceof InfinityChestTile) {
                ItemStack chestItem = ((InfinityChestTile)tileEntity).getStack();
                if (chestItem != null) {
                    renderChestItemInfoOnBlock(chestItem, MOP, event.player, event.partialTicks);
                }
            }
        }
    }

    private void renderChestItemInfoOnStatusBar(ItemStack holdItem, float partialTicks) {
        if (!holdItem.hasTagCompound()) return;
        ItemStack chestItem = InfinityChestTile.readFromNBTCustom((NBTTagCompound)holdItem.getTagCompound().getTag("chestItem"));
        if (chestItem != null) {
            String chestData = chestItem.getDisplayName() + " " + ClientStringUtils.formatStack(chestItem.stackSize);
            int x = mc.displayWidth;
            int y = mc.displayHeight;
/*            if (ForgeVersion.getBuildVersion() > 1147) {
                ScaledResolution scaledresolution = new ScaledResolution(mc, x, y);
                x = scaledresolution.getScaledWidth() >> 1;
                y = scaledresolution.getScaledHeight();
            }*/
            int sw = mc.fontRenderer.getStringWidth(chestData) >> 1;
            mc.fontRenderer.drawString(chestData, x - sw, y - 72 , 0xffffff);
        }
    }

    private void renderChestItemInfoOnBlock(ItemStack chestItem, MovingObjectPosition MOP, EntityPlayer player, float partialTicks) {
        String chestData = ClientStringUtils.formatStack(chestItem.stackSize);
        float scale = 0.01f;
        GL11.glPushMatrix();
        GL11.glTranslated(-player.posX, -player.posY, -player.posZ);
        GL11.glTranslatef(MOP.blockX + 0.5F, MOP.blockY + 0.5F, MOP.blockZ + 0.5F);
        int facing = MOP.sideHit;
        ForgeDirection direction = ForgeDirection.getOrientation(facing);
        GL11.glTranslatef(0.5F * direction.offsetX, 0.5F * direction.offsetY, 0.5F * direction.offsetZ);
        GL11.glNormal3f(0.0F, 1.0F, 0.0F);
        GL11.glScalef(-scale, -scale, scale);

        float rotationYaw = 0;
        if (facing == 2) rotationYaw =   0F;
        if (facing == 3) rotationYaw = 180F;
        if (facing == 4) rotationYaw = 270F;
        if (facing == 5) rotationYaw =  90F;
        GL11.glRotatef(rotationYaw, 0.0F, 1.0F, 0.0F);
        float rotationPitch = 0;
        if (facing == 1) rotationPitch = -90F;
        if (facing == 0) rotationPitch =  90F;
        GL11.glRotatef(rotationPitch, 1.0F, 0.0F, 0.0F);
//        GL11.glDisable(GL11.GL_LIGHTING);
//        GL11.glTranslatef(0.0F, 0.25F / f1, 0.0F);
//        GL11.glDepthMask(false);
//        GL11.glEnable(GL11.GL_BLEND);
//        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
//        Tessellator tessellator = Tessellator.instance;
//        GL11.glDisable(GL11.GL_TEXTURE_2D);
//        tessellator.startDrawingQuads();
        int i = mc.fontRenderer.getStringWidth(chestData) / 2;
//        tessellator.setColorRGBA_F(0.0F, 0.0F, 0.0F, 0.25F);
//        tessellator.addVertex((double)(-i - 1), -1.0D, 0.0D);
//        tessellator.addVertex((double)(-i - 1), 8.0D, 0.0D);
//        tessellator.addVertex((double)(i + 1), 8.0D, 0.0D);
//        tessellator.addVertex((double)(i + 1), -1.0D, 0.0D);
//        tessellator.draw();
//        GL11.glEnable(GL11.GL_TEXTURE_2D);
//        GL11.glDepthMask(true);
        mc.fontRenderer.drawString(chestData, -i, 0, 0xFFFFFF);
//        GL11.glEnable(GL11.GL_LIGHTING);
//        GL11.glDisable(GL11.GL_BLEND);
//        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glPopMatrix();
    }
}
