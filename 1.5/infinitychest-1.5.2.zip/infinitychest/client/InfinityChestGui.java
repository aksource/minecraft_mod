package infinitychest.client;

import infinitychest.InfinityChestContainer;
import infinitychest.InfinityChestTile;

import java.util.ArrayList;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.StatCollector;

import org.lwjgl.opengl.GL11;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class InfinityChestGui extends GuiContainer
{
	private IInventory player;
	private InfinityChestTile tile;

    private static final String GUI = "/mods/infinitychest/textures/gui/TextureInfinityGui.png";

	public InfinityChestGui(IInventory playerInventory, IInventory tileInventory)
	{
		super(new InfinityChestContainer(playerInventory, tileInventory));
        itemRenderer = new InfinityRenderItem();
		player = playerInventory;
		tile = (InfinityChestTile)tileInventory;
		allowUserInput = false;
		xSize = 176;
		ySize = 166;
	}

	@Override
	protected void drawGuiContainerForegroundLayer(int p_146979_1_, int p_146979_2_)
	{
        fontRenderer.drawString(String.format(StatCollector.translateToLocal(tile.getInvName())
			 , ClientStringUtils.formatMax(InfinityChestTile.stackLimit)), 8, 5, 0x404040);
        fontRenderer.drawString(StatCollector.translateToLocal(player.getInvName()), 8, 72, 0x404040);
		if(tile.hasStack())
		{

			ItemStack stack = tile.getStack();
			String name = stack.getDisplayName();
			fontRenderer.drawString(name, 35, 17, 0x404040);

			String count = ClientStringUtils.formatStack(stack.stackSize);
			fontRenderer.drawString(count, 47, 29, 0x404040);//47

			String lc = ClientStringUtils.formatLC(stack.stackSize);
			fontRenderer.drawString(lc, 164 - fontRenderer.getStringWidth(lc) , 40, 0x404040);//92

			ArrayList info = new ArrayList();
			stack.getItem().addInformation(stack, ClientStringUtils.mc.thePlayer, info, false);
			if(info.size() > 0)
			{
				for(int i = 0; i < info.size(); i++)
				{
					fontRenderer.drawString((String)info.get(i), 7, 42 + i*10, 0x404040);
				}
			}

		}
	}

	@Override
	protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3)
	{
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		mc.renderEngine.bindTexture(GUI);
		int x = (width - xSize) / 2;
		int y = (height - ySize) / 2;
		drawTexturedModalRect(x, y, 0, 0, xSize, ySize);
	}

}
