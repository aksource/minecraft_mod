package infinitychest;

import static infinitychest.InfinityChest.*;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import cpw.mods.fml.common.registry.GameRegistry;

public class CE
{
    //	private static boolean isBC = false;

    public static Item itemStorageBox;
    public static int renderChestID = 0;

    public static void init()
	{
		GameRegistry.registerTileEntity(InfinityChestTile.class, "InfinityChest");
        InfinityChest.proxy.registerClientInformation();
		int maxStack = InfinityChestTile.stackLimit;

		ItemStack infiChest = new ItemStack(infinityChest);
		ItemStack chest = new ItemStack(Block.chest);
		ItemStack glass = new ItemStack(Block.glass);
		ItemStack enderPearl = new ItemStack(Item.enderPearl);
		GameRegistry.addRecipe(infiChest, "ggg", "pcp", "ggg", 'p', enderPearl, 'c', chest, 'g', glass);

//		isBC = Loader.isModLoaded("mod_BuildCraftBuilders");
//		if(isBC)
//		{
//			new BptBlockRotateInventory(blockID_infinityChest, new int[]{2, 5, 3, 4}, true);
//		}
	}

    public static boolean isCreative(EntityPlayer player)
	{
		return player.capabilities.isCreativeMode;
	}

    public static boolean isDebug()
	{
		return true;
	}
}