package infinitychest;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.common.collect.Sets;

import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.INetworkManager;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.Packet132TileEntityData;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.oredict.OreDictionary;

public class InfinityChestTile extends TileEntity implements ISidedInventory
{
	private ItemStack chestItem;
	private ItemStack inputSlot;
    private Set<Integer> chestItemOreIds = Sets.newHashSet();
	public static int stackLimit = 20*10000*10000;
	private static InfinityChestContainer container = null;

	public void setContainer(InfinityChestContainer cont)
	{
		container = cont;
	}

	@Override
	public void onInventoryChanged()
	{
		if(isMax())
		{
			inputSlot = getCopy(chestItem.getMaxStackSize());
		}else{
			inputSlot = null;
		}
		if(container != null) container.changeSlot();

        @SuppressWarnings("unchecked")
        List<EntityPlayer> list= this.worldObj.playerEntities;
        for (EntityPlayer player : list) {
            if (player instanceof EntityPlayerMP) {
                ((EntityPlayerMP)player).playerNetServerHandler.sendPacketToPlayer(this.getDescriptionPacket());
            }
        }
    }

	public ItemStack getCopy()
	{
		return getCopy(1);
	}

	public ItemStack getCopy(int size)
	{
		if(!hasStack()) return null;
		ItemStack stack = chestItem.copy();
		stack.stackSize = size;
		return stack;
	}

	public ItemStack getStack()
	{
		return getStackInSlot(0);
	}

	public void setStack(ItemStack stack)
	{
		setStack(stack, false);
	}

	public void setStack(ItemStack stack, boolean isBlockSet)
	{
		if(isBlockSet)
		{
			chestItem = stack;
            addOreName(stack);
			this.onInventoryChanged();
		}else{
			setInventorySlotContents(0, stack);
		}
	}

	public boolean hasStack()
	{
		if(chestItem != null && chestItem.stackSize <= 0) chestItem = null;
		return chestItem != null;
	}

	public boolean isMax()
	{
		return (chestItem != null && chestItem.stackSize >= stackLimit);
	}

	public boolean isItemEqual(ItemStack stack)
	{
		return chestItem != null && isStackable(stack) && (stack.isItemEqual(chestItem) || isItemOreEqual(stack));
	}

    protected boolean isItemOreEqual(ItemStack stack) {
        if (!InfinityChest.doOreNameConvert) return false;
        addOreName(chestItem);
        if (chestItemOreIds.isEmpty()) return false;
        Set<Integer> set = getOreIdSet(stack);
        set.retainAll(chestItemOreIds);
        return !set.isEmpty();
    }

	public boolean isStackable(ItemStack stack)
	{
		return stack != null && !stack.hasTagCompound() &&
			(!stack.isItemDamaged() || stack.getItemDamage() == 0);
	}

	public ItemStack decSize(int size)
	{
		return decrStackSize(0, size);
	}

	public ItemStack addSize(int size)
	{
		if(!hasStack()) return null;
		ItemStack result = null;
		if (chestItem.stackSize + size > stackLimit)
		{
			result = chestItem.copy();
			result.stackSize = stackLimit - chestItem.stackSize;
			chestItem.stackSize = stackLimit;
		}
		else
		{
			chestItem.stackSize += size;
		}
		onInventoryChanged();
		return result;
	}

	//stackをチェストに入れ、入りきらなかった数を返す
	public int addStack(ItemStack itemstack)
	{
		if(itemstack == null) return 0;
		int size = itemstack.stackSize;
		if(!hasStack())
		{
			chestItem = itemstack.copy();
            addOreName(itemstack);
			if(size > stackLimit)
			{
				chestItem.stackSize = stackLimit;
			}
			size -= chestItem.stackSize;
			return size;
		}
		if(!isItemEqual(itemstack)) return size;
		if (chestItem.stackSize + size > stackLimit)
		{
			size = chestItem.stackSize + size - stackLimit;
			chestItem.stackSize = stackLimit;
		}
		else
		{
			chestItem.stackSize += size;
			size = 0;
		}
		onInventoryChanged();
		return size;
	}

	//stackにチェストからアイテムを取り出し、取り出した数を返す。
	//itemLimitは取り出し先の最大スタックサイズ（0にするとstackの最大スタック数）
	public int decStack(ItemStack stack)
	{
		return decStack(stack, 0);
	}
	public int decStack(ItemStack stack, int itemLimit)
	{
		if(!isItemEqual(stack) || itemLimit < 0) return 0;
		if(itemLimit == 0) itemLimit = stack.getMaxStackSize();
		if(stack.stackSize >= itemLimit) return 0;
		int size = stack.stackSize;
		int max = itemLimit - size;

		if (max >= chestItem.stackSize)
		{
			size = chestItem.stackSize;
			chestItem = null;
            chestItemOreIds.clear();
		}
		else
		{
			size = max;
			chestItem.stackSize -= max;
		}
		onInventoryChanged();
		return size;
	}
    @Override
	public void updateEntity()
	{
	}
	@Override
	public int getSizeInventory()
	{
		return 2;
	}

	@Override
	public ItemStack getStackInSlot(int slot)
	{
		return slot == 1 ? inputSlot: chestItem;
	}

	@Override
	public ItemStack decrStackSize(int slot, int dec)
	{
		if(!hasStack()) return null;
        if (slot == 1) return null;
		if (chestItem.stackSize <= dec)
		{
			ItemStack result = chestItem.copy();
			chestItem = null;
			this.onInventoryChanged();
			return result;
		}
		else
		{
			ItemStack result = chestItem.splitStack(dec);
			this.onInventoryChanged();
			return result;
		}
	}

	@Override
	public ItemStack getStackInSlotOnClosing(int slot)
	{
		return slot == 1 ? inputSlot: chestItem;
	}

	@Override
	public void setInventorySlotContents(int slot, ItemStack setstack)
	{
		if(slot == 1)
		{
			int size = addStack(setstack);
			if(size > 0)
			{
				setstack.stackSize = size;
				popItems(setstack, 0.0F);
			}else{
				inputSlot = null;
			}

		}else{
			chestItem = setstack;
            addOreName(setstack);
			if (chestItem != null && chestItem.stackSize > this.getInventoryStackLimit())
			{
				chestItem.stackSize = this.getInventoryStackLimit();
			}
		}
		this.onInventoryChanged();
	}

	public void popItems(ItemStack stack)
	{
		popItems(stack, 1.0F);
	}

	public void popItems(ItemStack stack, float height)
	{
		float f = worldObj.rand.nextFloat() * 0.8F + 0.1F;
		float f1 = worldObj.rand.nextFloat() * 0.8F + 0.1F;
		float f2 = worldObj.rand.nextFloat() * 0.8F + 0.1F;
		EntityItem entityitem = new EntityItem(worldObj,
			(float)xCoord + f, (float)yCoord + f1 + 0.5F, (float)zCoord + f2, stack);
		float f3 = 0.05F;
		entityitem.motionX = (float)worldObj.rand.nextGaussian() * f3;
		entityitem.motionY = (float)worldObj.rand.nextGaussian() * f3 + height;
		entityitem.motionZ = (float)worldObj.rand.nextGaussian() * f3;
		worldObj.spawnEntityInWorld(entityitem);
	}

	@Override	//ISidedInventory
	public int[] getAccessibleSlotsFromSide(int side)
	{
        return new int[]{0,1};
	}

    @Override
    public boolean canExtractItem(int slot, ItemStack var2, int side) {
        return slot == 0;
    }

    @Override
    public boolean canInsertItem(int slot, ItemStack var2, int side) {
        return isStackValidForSlot(slot, var2);
    }

    @Override
    public String getInvName() {
        return "infinity.chest.container";
    }

    @Override
    public boolean isInvNameLocalized() {
        return false;
    }

    @Override
    public boolean isStackValidForSlot(int slot, ItemStack var2) {
        return slot == 1 && (this.chestItem == null || this.chestItem.isItemEqual(var2) && ItemStack.areItemStackTagsEqual(chestItem, var2));
    }

    @Override
	public void readFromNBT(NBTTagCompound nbt)
	{
		super.readFromNBT(nbt);
        if (nbt.getTag("chestItem") != null) {
            chestItem = readFromNBTCustom((NBTTagCompound)nbt.getTag("chestItem"));
        } else {
            chestItem = null;
        }

//        if (nbt.getTag("inputSlot") != null) {
//            inputSlot = readFromNBTCustom((NBTTagCompound)nbt.getTag("inputSlot"));
//        } else {
//            inputSlot = null;
//        }
	}

	@Override
	public void writeToNBT(NBTTagCompound nbt)
	{
		super.writeToNBT(nbt);
		setNBT(nbt);
	}

	public NBTTagCompound setNBT(NBTTagCompound nbt)
	{
        NBTTagCompound nbtTagCompound = new NBTTagCompound();

		if(chestItem != null)
		{
            nbtTagCompound.setShort("id", (short) chestItem.getItem().itemID);
            nbtTagCompound.setInteger("Count", chestItem.stackSize);
            nbtTagCompound.setShort("Damage", (short) chestItem.getItemDamage());

            if (chestItem.stackTagCompound != null)
            {
                nbtTagCompound.setTag("tag", chestItem.stackTagCompound);
            }
		}
        nbt.setTag("chestItem", nbtTagCompound);
//        if (inputSlot != null) {
//            nbt.setTag("inputSlot", inputSlot.writeToNBT(new NBTTagCompound()));
//        }
        return nbt;
	}

    public static NBTTagCompound setToNBTCustom(NBTTagCompound nbt, ItemStack stack) {
        NBTTagCompound nbtTagCompound = new NBTTagCompound();

        if(stack != null)
        {
//            chestItem.writeToNBT(nbtTagCompound);
            nbtTagCompound.setShort("id", (short) stack.getItem().itemID);
            nbtTagCompound.setInteger("Count", stack.stackSize);
            nbtTagCompound.setShort("Damage", (short) stack.getItemDamage());

            if (stack.stackTagCompound != null)
            {
                nbtTagCompound.setTag("tag", stack.stackTagCompound);
            }
        }
        nbt.setTag("chestItem", nbtTagCompound);
        return nbt;
    }

    public static ItemStack readFromNBTCustom(NBTTagCompound nbtTagCompound)
    {
        if (nbtTagCompound == null) return null;
        int itemID = nbtTagCompound.getShort("id");
        if (itemID == 0) return null;
        int stackSize = nbtTagCompound.getInteger("Count");
        int itemDamage = nbtTagCompound.getShort("Damage");

        if (itemDamage < 0)
        {
            itemDamage = 0;
        }

        ItemStack itemStack = new ItemStack(itemID, stackSize, itemDamage);

        if (nbtTagCompound.hasKey("tag"))
        {
            NBTTagCompound stackTagCompound = nbtTagCompound.getCompoundTag("tag");
            itemStack.setTagCompound(stackTagCompound);
        }

        return itemStack;
    }
	@Override
	public int getInventoryStackLimit()
	{
        return stackLimit;
//		if(!hasStack()) return stackLimit;
//		int limit = stackLimit - chestItem.stackSize;
//		return limit <= 64 ? limit: stackLimit;
	}

	@Override
	public boolean isUseableByPlayer(EntityPlayer par1EntityPlayer)
	{
		return this.worldObj.getBlockTileEntity(xCoord, yCoord, zCoord) == this ||
			par1EntityPlayer.getDistanceSq(
				(double)xCoord + 0.5D,
				(double)yCoord + 0.5D,
				(double)zCoord + 0.5D) <= 64.0D;
	}

	@Override
	public void openChest() {}

	@Override
	public void closeChest()
	{
		container = null;
        this.onInventoryChanged();
	}

    @Override
    public Packet getDescriptionPacket() {
        NBTTagCompound nbtTagCompound = new NBTTagCompound();
        this.writeToNBT(nbtTagCompound);
        return new Packet132TileEntityData(this.xCoord, this.yCoord, this.zCoord, 1, nbtTagCompound);
    }

    @Override
    public void onDataPacket(INetworkManager net, Packet132TileEntityData pkt) {
        this.readFromNBT(pkt.customParam1);
    }

    public Set<Integer> getOreIdSet(ItemStack stack) {
        Set<Integer> set = new HashSet<Integer>();
        int oreId = OreDictionary.getOreID(stack);
        if (oreId > -1) {
        	set.add(oreId);
        }
/*        for (int i : OreDictionary.getOreIDs(stack)) {
            set.add(i);
        }*/
        return set;
    }

    private void addOreName(ItemStack itemStack) {
        chestItemOreIds.clear();
        int oreId = OreDictionary.getOreID(itemStack);
        if (oreId > -1) {
        	chestItemOreIds.add(oreId);
        }
/*        for (int i : OreDictionary.getOreIDs(itemStack)) {
            chestItemOreIds.add(i);
        }*/
    }
}
