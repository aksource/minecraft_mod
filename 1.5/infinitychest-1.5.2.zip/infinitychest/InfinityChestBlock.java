package infinitychest;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Icon;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class InfinityChestBlock extends BlockContainer
{
    private Icon top;
    private Icon side;
    private Icon front;
    public static final String textureBlockTop = "infinitychest:infinitychest-top";
    public static final String textureBlockSide = "infinitychest:infinitychest-side";
    public static final String textureBlockFront = "infinitychest:infinitychest-front";

	public InfinityChestBlock(int par1)
	{
		super(par1, Material.glass);
		setHardness(0.3F);//Hardness取得にWorldと座標が必要になったため。
		setStepSound(Block.soundGlassFootstep);
	}

    @Override
    public void registerIcons(IconRegister iIconRegister) {
        top = iIconRegister.registerIcon(textureBlockTop);
        side = iIconRegister.registerIcon(textureBlockSide);
        front = iIconRegister.registerIcon(textureBlockFront);
    }

    @Override
    public Icon getIcon(int face, int meta) {
        return  (face < 2) ? top: (face == meta) ? front: side;
    }

	@Override
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int x, int y, int z)
	{
		double ps = 0.0625;
		double pe = 0.9375;
		double pt = 0.8750;
		return AxisAlignedBB.getBoundingBox(
			(double)x + ps, (double)y, (double)z + ps,
			(double)x + pe, (double)y + pt, (double)z + pe);
	}

	@Override
	public void setBlockBoundsBasedOnState(IBlockAccess world, int x, int y, int z)
	{
		float ps = 0.0625F;
		float pe = 0.9375F;
		float pt = 0.8750F;
		this.setBlockBounds(ps, 0.0F, ps, pe, pt, pe);
	}

	@Override
	public int getRenderBlockPass()
	{
		return 1;
	}

	@Override
	public boolean isOpaqueCube()
	{
		return false;
	}

	@Override
	public boolean renderAsNormalBlock()
	{
		return false;
	}

    @Override
    public void onBlockPlacedBy(World world, int x, int y, int z, EntityLiving entityLiving, ItemStack itemStack) {
        int meta = determineOrientation(world, x, y, z, (EntityPlayer)entityLiving);
        world.setBlockMetadataWithNotify(x, y, z, meta, 3);

        if(itemStack.hasTagCompound())
        {
            InfinityChestTile tile = (InfinityChestTile)createTileEntity(world, meta);
            world.setBlockTileEntity(x, y, z, tile);
            NBTTagCompound nbt = (NBTTagCompound)itemStack.getTagCompound().getTag("chestItem");
            ItemStack chestItem = InfinityChestTile.readFromNBTCustom(nbt);
            tile.setStack(chestItem, true);
        }
    }

	public static int determineOrientation(World world, int x, int y, int z, EntityPlayer player)
	{
		int face = MathHelper.floor_double((double) (player.rotationYaw * 4.0F / 360.0F) + 0.5D) & 3;
		return face == 0 ? 2 : (face == 1 ? 5 : (face == 2 ? 3 : (face == 3 ? 4 : 3)));
	}

    @Override
    public void onBlockHarvested(World world, int x, int y, int z, int meta, EntityPlayer harvester) {
        dropInfinityChestWithNBT(world, x, y, z);
        super.onBlockHarvested(world, x, y, z, meta, harvester);
    }

    //	private static final Map<ChunkCoordinates, InfinityChestTile> removeTileEntityMap = new HashMap<>();

//	@Override
//    public void breakBlock(World world, int x, int y, int z, Block par5, int par6)
//	{
//		removeTileEntityMap.put(new ChunkCoordinates(x, y, z), (InfinityChestTile)world.getTileEntity(x, y, z));
//        dropInfinityChestWithNBT(world, x, y, z);
//		super.breakBlock(world, x, y, z, par5, par6);
//	}

    private void dropInfinityChestWithNBT(World world, int x, int y, int z) {
        InfinityChestTile infinityChestTile = (InfinityChestTile)world.getBlockTileEntity(x, y, z)/*removeTileEntityMap.remove(new ChunkCoordinates(x, y, z))*/;
        if (!world.isRemote && infinityChestTile != null)
        {
            ItemStack stack = new ItemStack(this, 1, 0);
            if (infinityChestTile.hasStack())
            {
                stack.setTagCompound(infinityChestTile.setNBT(new NBTTagCompound()));
            }

            EntityItem drop = new EntityItem(world, x + 0.5, y + 0.5, z + 0.5, stack);
            drop.motionX = 0.0F;
            drop.motionY = 0.2F;
            drop.motionZ = 0.0F;
            world.spawnEntityInWorld(drop);
        }
    }

	@Override
	public int quantityDropped(Random par1Random)
	{
		return 0;
	}

    @Override
    public TileEntity createTileEntity(World var1, int var2) {
        return new InfinityChestTile();
    }

	@Override
	public int getRenderType()
	{
		return CE.renderChestID;
	}

//	private static int infiGuiID = 1;

    @Override
    public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int p_149727_6_, float hitX, float hitY, float hitZ) {
        InfinityChestTile tile = (InfinityChestTile)world.getBlockTileEntity(x, y, z);
        if (tile == null || world.isRemote) return true;
//        ItemStack stack = player.getCurrentEquippedItem();
//        if(stack != null)
//        {
//            if(stack.getItem().equals(CE.itemStorageBox) && stack.stackSize == 1)
//            {
//                if(onStorageBox(world, player, tile, stack)) return true;
//            }
//        }

        player.openGui(InfinityChest.instance, CommonProxy.infiGuiID, world, x, y, z);
        return true;
    }

@Override
public TileEntity createNewTileEntity(World world) {
	return createTileEntity(world, 0);
}



}
