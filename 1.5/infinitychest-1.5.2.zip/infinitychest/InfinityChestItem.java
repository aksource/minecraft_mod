package infinitychest;

import infinitychest.client.ClientStringUtils;

import java.util.List;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class InfinityChestItem extends ItemBlock
{

	public InfinityChestItem(int par1)
	{
		super(par1);
	}


	@Override
	public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ)
	{
		boolean result = super.onItemUse(stack, player, world, x, y, z, side, hitX, hitY, hitZ);
		if(result && stack.stackSize <= 0)
		{
			InventoryPlayer pinv = player.inventory;
			stack.stackSize = 1;
			pinv.setInventorySlotContents(pinv.currentItem, null);
		}
		return result;
	}

	@Override
    @SuppressWarnings("unchecked")
	public void addInformation(ItemStack itemStack, EntityPlayer player, List par3List, boolean par4)
	{
		if(itemStack.hasTagCompound())
		{
			ItemStack chestItem = InfinityChestTile.readFromNBTCustom((NBTTagCompound)itemStack.getTagCompound().getTag("chestItem"));

            if (chestItem != null) {
                par3List.add("  " + chestItem.getDisplayName());
                par3List.add("  " + ClientStringUtils.formatStack(chestItem.stackSize));
                chestItem.getItem().addInformation(chestItem, player, par3List, par4);
            }
        }
	}

}
